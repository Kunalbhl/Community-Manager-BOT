export type OperationalErrorCategory =
  | 'AUTHENTICATION_FAILED'
  | 'AUTHORIZATION_FAILED'
  | 'TENANT_CONTEXT_FAILED'
  | 'VALIDATION_FAILED'
  | 'NOT_FOUND'
  | 'CONFLICT'
  | 'RATE_LIMITED'
  | 'DISCORD_UNAVAILABLE'
  | 'DISCORD_PERMISSION_FAILED'
  | 'DATABASE_UNAVAILABLE'
  | 'AI_PROCESSING_FAILED'
  | 'BILLING_FAILED'
  | 'WEBHOOK_FAILED'
  | 'AUTOMATION_FAILED'
  | 'TIMEOUT'
  | 'DEPENDENCY_UNAVAILABLE'
  | 'INTERNAL_ERROR';

export type DependencyStatus = 'HEALTHY' | 'DEGRADED' | 'UNAVAILABLE' | 'NOT_CONFIGURED';

export interface DependencyHealthReport {
  name: string;
  status: DependencyStatus;
  lastCheckedAt: string;
  latencyMs?: number;
  details?: string;
  recoveryAction?: string;
}

export interface SystemHealthOverview {
  status: 'HEALTHY' | 'DEGRADED' | 'UNAVAILABLE';
  uptimeSeconds: number;
  metrics: {
    totalRequests: number;
    totalErrors: number;
    errorRatePercent: number;
    avgLatencyMs: number;
    activeIncidents: number;
  };
  dependencies: Record<string, DependencyHealthReport>;
}

export type IncidentSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type IncidentStatus = 'OPEN' | 'ACKNOWLEDGED' | 'RESOLVED';

export interface IncidentDocument {
  id: string;
  category: OperationalErrorCategory;
  severity: IncidentSeverity;
  status: IncidentStatus;
  correlationId: string;
  dependency: string;
  summary: string;
  firstSeenAt: string;
  lastSeenAt: string;
  occurrenceCount: number;
  resolvedAt?: string;
  communityId?: string;
  workspaceId?: string;
  recoveryInstructions?: string;
}

export interface ScheduledJobStatus {
  id: string;
  jobName: string;
  module: 'announcements' | 'reminders' | 'campaigns' | 'events' | 'automation' | 'billing_webhook';
  lastExecutionAt?: string;
  nextExecutionAt?: string;
  lastStatus: 'SUCCESS' | 'FAILURE' | 'RUNNING' | 'IDLE';
  executionCount: number;
  failureCount: number;
  lastError?: string;
  intervalMs?: number;
}

export interface TenantHealthReport {
  communityId: string;
  status: 'HEALTHY' | 'DEGRADED' | 'ATTENTION_REQUIRED';
  discordConnected: boolean;
  botPermissionsValid: boolean;
  sheetsConnected: boolean;
  activeIncidentsCount: number;
  lastSyncAt: string;
  issues: string[];
}
