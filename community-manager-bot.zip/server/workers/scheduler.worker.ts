import { db } from '../config/firestore.js';
import { logger } from '../logging/logger.js';
import { EngagementSchedulerService } from '../services/engagement.service.js';

export class SchedulerWorker {
  private isRunning = false;
  private intervalTimer: NodeJS.Timeout | null = null;

  start(intervalMs = 30000) {
    if (this.isRunning) return;
    this.isRunning = true;
    logger.info('[SchedulerWorker] Started execution lock polling.');

    this.intervalTimer = setInterval(async () => {
      try {
        await this.processScheduledEngagements();
      } catch (err: any) {
        logger.error('[SchedulerWorker] Execution error:', undefined, { error: err?.message });
      }
    }, intervalMs);
  }

  stop() {
    if (this.intervalTimer) {
      clearInterval(this.intervalTimer);
      this.intervalTimer = null;
    }
    this.isRunning = false;
    logger.info('[SchedulerWorker] Stopped.');
  }

  async processScheduledEngagements() {
    await EngagementSchedulerService.processScheduledJobs();
  }
}

export const schedulerWorker = new SchedulerWorker();
