import {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionFlagsBits,
  RESTJSONErrorCodes,
} from 'discord.js';
import {
  DiscordProvider,
  DiscordMessageResult,
  DiscordGatewayState,
  DiscordGatewayDiagnostics,
} from './discord.interface.js';
import { attachGatewayEventHandlers } from './events/index.js';
import { config } from '../../config/env.js';
import { logger } from '../../logging/logger.js';
import { secretsManager } from '../../security/secrets.js';

export class RealDiscordProvider implements DiscordProvider {
  client: Client | null = null;
  private state: DiscordGatewayState = 'NOT_CONFIGURED';
  private connectedAt?: string;
  private lastHeartbeatAt?: string;
  private disconnectReason?: string;
  private heartbeatInterval?: NodeJS.Timeout;
  private connectionPromise: Promise<boolean> | null = null;

  constructor() {
    this.updateInitialState();
  }

  private updateInitialState() {
    if (!config.DISCORD_BOT_TOKEN || config.DISCORD_BOT_TOKEN.startsWith('mock_')) {
      this.state = 'NOT_CONFIGURED';
    } else {
      this.state = 'DISCONNECTED';
    }
  }

  isConfigured(): boolean {
    return Boolean(config.DISCORD_BOT_TOKEN && !config.DISCORD_BOT_TOKEN.startsWith('mock_'));
  }

  isConnected(): boolean {
    return this.state === 'CONNECTED' && Boolean(this.client?.isReady());
  }

  getGuild(guildId: string): any {
    return this.client?.isReady() ? this.client.guilds.cache.get(guildId) || null : null;
  }

  getConnectionState(): DiscordGatewayState {
    return this.state;
  }

  getDiagnostics(): DiscordGatewayDiagnostics {
    const isReady = Boolean(this.client?.isReady());
    const intents: string[] = [
      'Guilds',
      'GuildMembers',
      'GuildMessages',
      'DirectMessages',
    ];

    const effectiveState = (!config.DISCORD_BOT_TOKEN || config.DISCORD_BOT_TOKEN.startsWith('mock_'))
      ? 'NOT_CONFIGURED'
      : this.state;

    return {
      state: effectiveState,
      botTag: isReady ? this.client?.user?.tag : undefined,
      botUserId: isReady ? this.client?.user?.id : undefined,
      guildsCount: isReady ? (this.client?.guilds.cache.size || 0) : 0,
      pingMs: isReady ? (this.client?.ws.ping || 0) : -1,
      connectedAt: this.connectedAt,
      lastHeartbeatAt: this.lastHeartbeatAt,
      disconnectReason: this.disconnectReason,
      intentsEnabled: intents,
      messageContentIntentActive: false,
    };
  }

  async connect(): Promise<boolean> {
    if (this.connectionPromise) {
      logger.info('[DiscordGateway] Bot connection in progress. Returning existing connection promise.');
      return this.connectionPromise;
    }

    if (this.client) {
      logger.info('[DiscordGateway] Bot is already connected. Skipping duplicate connection.');
      return true;
    }

    this.connectionPromise = (async () => {
      if (!config.DISCORD_BOT_TOKEN || config.DISCORD_BOT_TOKEN.startsWith('mock_')) {
        this.state = 'NOT_CONFIGURED';
        logger.info('[DiscordGateway] DISCORD_BOT_TOKEN not provided or unconfigured placeholder in environment. Gateway remains NOT_CONFIGURED.');
        this.connectionPromise = null;
        return false;
      }

      try {
        this.state = 'CONNECTING';
        logger.info('[DiscordGateway] Initializing Discord Gateway client...');

        this.client = new Client({
          intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMembers,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.DirectMessages,
          ],
          partials: [Partials.Channel, Partials.Message, Partials.User],
        });

        // Attach all real Gateway event listeners
        attachGatewayEventHandlers(this.client);

        // Setup connection lifecycle listeners
        this.client.on('shardReady', (shardId) => {
          this.state = 'CONNECTED';
          this.connectedAt = new Date().toISOString();
          this.lastHeartbeatAt = new Date().toISOString();
          this.disconnectReason = undefined;
          logger.info(`[DiscordGateway] Shard ${shardId} connected successfully.`);
        });

        this.client.on('shardDisconnect', (event, shardId) => {
          this.state = 'DISCONNECTED';
          this.disconnectReason = `Shard ${shardId} disconnected: ${event.reason || 'Code ' + event.code}`;
          logger.warn(`[DiscordGateway] ${this.disconnectReason}`);
        });

        this.client.on('shardReconnecting', (shardId) => {
          this.state = 'RECONNECTING';
          logger.info(`[DiscordGateway] Shard ${shardId} reconnecting...`);
        });

        this.client.on('shardError', (error, shardId) => {
          this.state = 'FAILED';
          this.disconnectReason = `Shard ${shardId} error: ${error.message}`;
          logger.error(`[DiscordGateway] Shard ${shardId} error:`, undefined, {
            error: error.message,
          });
        });

        // Track regular heartbeats
        if (this.heartbeatInterval) {
          clearInterval(this.heartbeatInterval);
        }
        this.heartbeatInterval = setInterval(() => {
          if (this.client?.isReady()) {
            this.lastHeartbeatAt = new Date().toISOString();
          }
        }, 30000);

        await this.client.login(config.DISCORD_BOT_TOKEN);
        this.state = 'CONNECTED';
        this.connectedAt = new Date().toISOString();
        this.lastHeartbeatAt = new Date().toISOString();
        return true;
      } catch (err) {
        const errMsg = (err as Error).message;
        if (errMsg.includes('TOKEN_INVALID') || errMsg.includes('401')) {
          this.state = 'AUTHENTICATION_REQUIRED';
        } else {
          this.state = 'FAILED';
        }
        this.disconnectReason = secretsManager.redactString(errMsg);
        logger.error('[DiscordGateway] Login failed:', undefined, {
          state: this.state,
          error: this.disconnectReason,
        });
        this.client = null;
        this.connectionPromise = null;
        return false;
      }
    })();

    return this.connectionPromise;
  }

  async disconnect(): Promise<void> {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = undefined;
    }

    if (this.client) {
      await this.client.destroy();
      this.client = null;
      this.state = 'DISCONNECTED';
      this.disconnectReason = 'Manual disconnect requested';
      logger.info('[DiscordGateway] Bot disconnected cleanly.');
    }
  }

  async sendDM(discordUserId: string, content: string): Promise<DiscordMessageResult> {
    if (!this.isConnected() || !this.client) {
      throw new Error('DISCORD_BOT_NOT_CONNECTED: Cannot send DM because the bot is not connected to Discord Gateway.');
    }

    try {
      const user = await this.client.users.fetch(discordUserId);
      const msg = await user.send(content);
      return {
        messageId: msg.id,
        channelId: msg.channelId,
        sentAt: msg.createdAt.toISOString(),
        success: true,
      };
    } catch (err: unknown) {
      logger.error(`[DiscordGateway] Failed to send DM to ${discordUserId}: ${(err as Error).message}`);
      throw err;
    }
  }

  async sendChannelMessage(channelId: string, content: string): Promise<DiscordMessageResult> {
    if (!this.isConnected() || !this.client) {
      throw new Error('DISCORD_BOT_NOT_CONNECTED: Cannot send channel message because the bot is not connected to Discord Gateway.');
    }

    try {
      const channel = await this.client.channels.fetch(channelId);
      if (channel && channel.isTextBased() && 'send' in channel) {
        const msg = await (channel as unknown as { send: (c: string) => Promise<{ id: string; channelId: string; createdAt: Date }> }).send(content);
        return {
          messageId: msg.id,
          channelId: msg.channelId,
          sentAt: msg.createdAt.toISOString(),
          success: true,
        };
      }
      throw new Error(`Channel ${channelId} is not a valid text-based channel`);
    } catch (err) {
      logger.error(`[DiscordGateway] Failed to send channel message to ${channelId}: ${(err as Error).message}`);
      throw err;
    }
  }

  async assignRole(guildId: string, discordUserId: string, roleId: string): Promise<{ success: boolean; error?: string }> {
    if (!this.isConnected() || !this.client) {
      return { success: false, error: 'DISCORD_BOT_NOT_CONNECTED' };
    }

    try {
      const guild = await this.client.guilds.fetch(guildId);
      const botMember = await guild.members.fetchMe();

      if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
        return { success: false, error: 'BOT_MISSING_MANAGE_ROLES_PERMISSION' };
      }

      const role = await guild.roles.fetch(roleId);
      if (!role) {
        return { success: false, error: 'ROLE_NOT_FOUND' };
      }

      if (botMember.roles.highest.position <= role.position) {
        return { success: false, error: 'ROLE_HIERARCHY_CONFLICT: Bot role must be higher than assigned role' };
      }

      const member = await guild.members.fetch(discordUserId);
      await member.roles.add(roleId);
      return { success: true };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  }

  async removeRole(guildId: string, discordUserId: string, roleId: string): Promise<{ success: boolean; error?: string }> {
    if (!this.isConnected() || !this.client) {
      return { success: false, error: 'DISCORD_BOT_NOT_CONNECTED' };
    }

    try {
      const guild = await this.client.guilds.fetch(guildId);
      const member = await guild.members.fetch(discordUserId);
      await member.roles.remove(roleId);
      return { success: true };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  }

  async createRole(guildId: string, options: { name: string; color?: string; mentionable?: boolean; hoist?: boolean }): Promise<{ success: boolean; role?: any; error?: string }> {
    if (!this.isConnected() || !this.client) {
      return { success: false, error: 'DISCORD_BOT_NOT_CONNECTED' };
    }

    try {
      const guild = await this.client.guilds.fetch(guildId);
      const botMember = await guild.members.fetchMe();
      if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
        return { success: false, error: 'BOT_MISSING_MANAGE_ROLES_PERMISSION' };
      }

      const createdRole = await guild.roles.create({
        name: options.name,
        color: options.color as any,
        mentionable: options.mentionable ?? false,
        hoist: options.hoist ?? false,
        reason: 'Created via Community Manager Discord Operations',
      });

      return {
        success: true,
        role: {
          id: createdRole.id,
          name: createdRole.name,
          color: createdRole.hexColor,
          position: createdRole.position,
          mentionable: createdRole.mentionable,
          hoist: createdRole.hoist,
          managed: createdRole.managed,
        },
      };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  }

  async updateRole(guildId: string, roleId: string, updates: { name?: string; color?: string; mentionable?: boolean; hoist?: boolean }): Promise<{ success: boolean; role?: any; error?: string }> {
    if (!this.isConnected() || !this.client) {
      return { success: false, error: 'DISCORD_BOT_NOT_CONNECTED' };
    }

    try {
      const guild = await this.client.guilds.fetch(guildId);
      const botMember = await guild.members.fetchMe();
      if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
        return { success: false, error: 'BOT_MISSING_MANAGE_ROLES_PERMISSION' };
      }

      const role = await guild.roles.fetch(roleId);
      if (!role) {
        return { success: false, error: 'ROLE_NOT_FOUND' };
      }

      if (role.managed) {
        return { success: false, error: 'CANNOT_MODIFY_MANAGED_BOT_ROLE' };
      }

      if (botMember.roles.highest.position <= role.position) {
        return { success: false, error: 'ROLE_HIERARCHY_CONFLICT: Bot role must be higher than target role' };
      }

      const updated = await role.edit({
        name: updates.name ?? role.name,
        color: updates.color as any ?? role.color,
        mentionable: updates.mentionable ?? role.mentionable,
        hoist: updates.hoist ?? role.hoist,
        reason: 'Updated via Community Manager Discord Operations',
      });

      return {
        success: true,
        role: {
          id: updated.id,
          name: updated.name,
          color: updated.hexColor,
          position: updated.position,
          mentionable: updated.mentionable,
          hoist: updated.hoist,
          managed: updated.managed,
        },
      };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  }

  async createChannel(guildId: string, options: { name: string; type?: number | string; parentId?: string; topic?: string }): Promise<{ success: boolean; channel?: any; error?: string }> {
    if (!this.isConnected() || !this.client) {
      return { success: false, error: 'DISCORD_BOT_NOT_CONNECTED' };
    }

    try {
      const guild = await this.client.guilds.fetch(guildId);
      const botMember = await guild.members.fetchMe();
      if (!botMember.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return { success: false, error: 'BOT_MISSING_MANAGE_CHANNELS_PERMISSION' };
      }

      const channel = await guild.channels.create({
        name: options.name,
        topic: options.topic,
        parent: options.parentId,
        reason: 'Created via Community Manager Discord Operations',
      });

      return {
        success: true,
        channel: {
          id: channel.id,
          name: channel.name,
          type: channel.type,
          parentId: channel.parentId,
        },
      };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  }

  async updateChannel(guildId: string, channelId: string, updates: { name?: string; topic?: string }): Promise<{ success: boolean; channel?: any; error?: string }> {
    if (!this.isConnected() || !this.client) {
      return { success: false, error: 'DISCORD_BOT_NOT_CONNECTED' };
    }

    try {
      const guild = await this.client.guilds.fetch(guildId);
      const botMember = await guild.members.fetchMe();
      if (!botMember.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return { success: false, error: 'BOT_MISSING_MANAGE_CHANNELS_PERMISSION' };
      }

      const channel = await guild.channels.fetch(channelId);
      if (!channel) {
        return { success: false, error: 'CHANNEL_NOT_FOUND' };
      }

      if ('edit' in channel && typeof channel.edit === 'function') {
        const updated = await (channel as any).edit({
          name: updates.name ?? (channel as any).name,
          topic: updates.topic ?? (channel as any).topic,
          reason: 'Updated via Community Manager Discord Operations',
        });
        return {
          success: true,
          channel: {
            id: updated.id,
            name: updated.name,
            type: updated.type,
          },
        };
      }

      return { success: false, error: 'CHANNEL_CANNOT_BE_EDITED' };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  }
}

export class DevelopmentDiscordProvider implements DiscordProvider {
  client: any;
  private state: DiscordGatewayState = 'DISCONNECTED';
  private connectedAt: string = new Date().toISOString();

  constructor() {
    this.client = {
      guilds: {
        cache: {
          get: (guildId: string) => this.getMockGuild(guildId),
          size: 2,
          [Symbol.iterator]: function*() {
            yield ['guild_sim_1', { id: 'guild_sim_1', name: 'Simulated Server 1' }];
            yield ['guild_sim_2', { id: 'guild_sim_2', name: 'Simulated Server 2' }];
          }
        },
        fetch: async (guildId: string) => this.getMockGuild(guildId)
      },
      channels: {
        fetch: async (channelId: string) => this.getMockChannel(channelId)
      }
    };
  }

  private getMockGuild(guildId: string) {
    return {
      id: guildId,
      name: `Simulated Server ${guildId.slice(-4)}`,
      memberCount: 42,
      iconURL: () => 'https://cdn.discordapp.com/icons/guild_sim_1/abc.png',
      members: {
        fetchMe: async () => ({
          permissions: {
            bitfield: {
              toString: () => '1099511627775'
            }
          }
        }),
        fetch: async (userId: string) => ({
          id: userId,
          displayName: `Simulated User ${userId.slice(-4)}`,
          roles: {
            add: async (roleId: string) => {},
            remove: async (roleId: string) => {}
          }
        })
      },
      roles: {
        fetch: async (roleId: string) => ({
          id: roleId,
          name: `Simulated Role ${roleId.slice(-4)}`,
          position: 10,
          managed: false,
          edit: async (updates: any) => ({
            id: roleId,
            name: updates.name || 'Updated Role',
            hexColor: updates.color || '#000000',
            position: 10,
            mentionable: updates.mentionable ?? false,
            hoist: updates.hoist ?? false,
            managed: false
          })
        }),
        create: async (options: any) => ({
          id: `role_sim_${Date.now()}`,
          name: options.name,
          hexColor: options.color || '#ffffff',
          position: 11,
          mentionable: options.mentionable ?? false,
          hoist: options.hoist ?? false,
          managed: false
        })
      },
      channels: {
        create: async (options: any) => ({
          id: `channel_sim_${Date.now()}`,
          name: options.name,
          type: options.type ?? 0,
          parentId: options.parentId
        })
      }
    };
  }

  private getMockChannel(channelId: string) {
    return {
      id: channelId,
      name: `simulated-channel`,
      type: 0,
      isTextBased: () => true,
      send: async (content: string) => ({
        id: `msg_dev_${Date.now()}`,
        channelId,
        createdAt: new Date()
      })
    };
  }

  isConfigured(): boolean {
    return Boolean(config.DISCORD_BOT_TOKEN && config.DISCORD_BOT_TOKEN !== '');
  }

  isConnected(): boolean {
    return this.state === 'CONNECTED';
  }

  getGuild(guildId: string): any {
    return this.isConnected() ? this.getMockGuild(guildId) : null;
  }

  getConnectionState(): DiscordGatewayState {
    if (!this.isConfigured()) {
      return 'NOT_CONFIGURED';
    }
    return this.state;
  }

  getDiagnostics(): DiscordGatewayDiagnostics {
    const connected = this.isConnected();
    return {
      state: this.getConnectionState(),
      botTag: connected ? 'SimulatedBot#1547' : undefined,
      botUserId: connected ? '1547515985416822884' : undefined,
      guildsCount: connected ? 2 : 0,
      pingMs: connected ? 15 : -1,
      connectedAt: connected ? this.connectedAt : undefined,
      lastHeartbeatAt: connected ? new Date().toISOString() : undefined,
      intentsEnabled: ['Guilds', 'GuildMembers', 'GuildMessages', 'DirectMessages'],
      messageContentIntentActive: connected,
    };
  }

  async connect(): Promise<boolean> {
    this.state = 'CONNECTED';
    this.connectedAt = new Date().toISOString();
    return true;
  }

  async disconnect(): Promise<void> {
    this.state = 'DISCONNECTED';
  }

  async sendDM(discordUserId: string, content: string): Promise<DiscordMessageResult> {
    if (!this.isConnected()) {
      return {
        messageId: `dev_dm_${Date.now()}`,
        channelId: `dm_${discordUserId}`,
        sentAt: new Date().toISOString(),
        success: false,
        failureReason: 'BOT_NOT_CONNECTED',
      };
    }
    return {
      messageId: `dev_dm_${Date.now()}`,
      channelId: `dm_${discordUserId}`,
      sentAt: new Date().toISOString(),
      success: true,
    };
  }

  async sendChannelMessage(channelId: string, content: string): Promise<DiscordMessageResult> {
    if (!this.isConnected()) {
      return {
        messageId: `dev_chan_${Date.now()}`,
        channelId,
        sentAt: new Date().toISOString(),
        success: false,
        failureReason: 'BOT_NOT_CONNECTED',
      };
    }
    return {
      messageId: `dev_chan_${Date.now()}`,
      channelId,
      sentAt: new Date().toISOString(),
      success: true,
    };
  }

  async assignRole(guildId: string, discordUserId: string, roleId: string): Promise<{ success: boolean; error?: string }> {
    if (!this.isConnected()) {
      return { success: false, error: 'DISCORD_BOT_NOT_CONNECTED' };
    }
    return { success: true };
  }

  async removeRole(guildId: string, discordUserId: string, roleId: string): Promise<{ success: boolean; error?: string }> {
    if (!this.isConnected()) {
      return { success: false, error: 'DISCORD_BOT_NOT_CONNECTED' };
    }
    return { success: true };
  }

  async createRole(guildId: string, options: { name: string; color?: string; mentionable?: boolean; hoist?: boolean }): Promise<{ success: boolean; role: any }> {
    return {
      success: true,
      role: {
        id: `role_sim_${Date.now()}`,
        name: options.name,
        color: options.color || '#ffffff',
        position: 10,
        mentionable: options.mentionable ?? false,
        hoist: options.hoist ?? false,
        managed: false,
      }
    };
  }

  async updateRole(guildId: string, roleId: string, updates: { name?: string; color?: string; mentionable?: boolean; hoist?: boolean }): Promise<{ success: boolean; role: any }> {
    return {
      success: true,
      role: {
        id: roleId,
        name: updates.name || 'Updated Role',
        color: updates.color || '#ffffff',
        position: 10,
        mentionable: updates.mentionable ?? false,
        hoist: updates.hoist ?? false,
        managed: false,
      }
    };
  }

  async createChannel(guildId: string, options: { name: string; type?: number | string; parentId?: string; topic?: string }): Promise<{ success: boolean; channel: any }> {
    return {
      success: true,
      channel: {
        id: `channel_sim_${Date.now()}`,
        name: options.name,
        type: options.type ?? 0,
        parentId: options.parentId,
      }
    };
  }

  async updateChannel(guildId: string, channelId: string, updates: { name?: string; topic?: string }): Promise<{ success: boolean; channel: any }> {
    return {
      success: true,
      channel: {
        id: channelId,
        name: updates.name || 'updated-channel',
        type: 0,
      }
    };
  }
}

export const discordService: DiscordProvider = config.APP_RUNTIME_MODE === 'DEVELOPMENT_SIMULATION'
  ? new DevelopmentDiscordProvider()
  : new RealDiscordProvider();

export { RealDiscordProvider as DiscordService };
