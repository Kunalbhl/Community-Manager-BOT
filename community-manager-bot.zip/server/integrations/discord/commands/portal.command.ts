import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { SlashCommandDefinition, CommandContext } from './types.js';
import { config } from '../../../config/env.js';
import { communitiesRepository } from '../../../repositories/index.js';

export const communityManagerPortalCommand: SlashCommandDefinition = {
  data: new SlashCommandBuilder()
    .setName('community-manager')
    .setDescription('Open the Community Manager Web Portal directly for your community'),
  category: 'PORTAL_SETUP',
  minimumRole: 'APPLICANT',
  status: 'ACTIVE',

  async execute(interaction, ctx: CommandContext) {
    const appUrl = config.APP_URL || 'http://localhost:3000';
    const guildId = interaction.guildId;

    let targetCommunityId = ctx.communityId;
    let isConnected = false;

    if (guildId) {
      // Resolve community for guild safely
      const comms = await communitiesRepository.list({
        where: [{ field: 'guildId', operator: '==', value: guildId }],
        limit: 1,
      });

      if (comms.length > 0 && comms[0].connectionStatus === 'CONNECTED') {
        targetCommunityId = comms[0].id;
        isConnected = true;
      }
    }

    if (isConnected && targetCommunityId) {
      const portalUrl = `${appUrl}/community/${targetCommunityId}`;
      const linkButton = new ButtonBuilder()
        .setLabel('Open Community Manager')
        .setStyle(ButtonStyle.Link)
        .setURL(portalUrl);

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(linkButton);

      await interaction.reply({
        content: `**Community Manager**\n\nOpen your community management dashboard to configure recruitment, moderation, automation and member management.`,
        components: [row],
        ephemeral: true,
      });
    } else if (guildId) {
      const setupUrl = `${appUrl}/onboarding?guild_id=${guildId}`;
      const setupButton = new ButtonBuilder()
        .setLabel('Set Up This Server')
        .setStyle(ButtonStyle.Link)
        .setURL(setupUrl);

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(setupButton);

      await interaction.reply({
        content: `**Community Manager**\n\nSet up this server to configure recruitment, rules, candidate workflows, and interview scheduling.`,
        components: [row],
        ephemeral: true,
      });
    } else {
      const loginUrl = `${appUrl}/login`;
      const loginButton = new ButtonBuilder()
        .setLabel('Open Community Manager')
        .setStyle(ButtonStyle.Link)
        .setURL(loginUrl);

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(loginButton);

      await interaction.reply({
        content: `**Community Manager**\n\nLog in with Discord to access your authorized community management workspaces.`,
        components: [row],
        ephemeral: true,
      });
    }
  },
};
