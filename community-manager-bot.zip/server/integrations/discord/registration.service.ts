import { REST, Routes } from 'discord.js';
import { discordCommands } from './commands/index.js';
import { config } from '../../config/env.js';
import { logger } from '../../logging/logger.js';

export interface CommandRegistrationResult {
  status: 'SUCCESS' | 'NOT_CONFIGURED' | 'FAILED';
  commandsCount: number;
  registeredNames: string[];
  scope: 'GLOBAL' | 'GUILD' | 'NONE';
  error?: string;
}

/**
 * Registers application slash commands with the Discord REST API.
 */
export async function registerSlashCommands(guildId?: string): Promise<CommandRegistrationResult> {
  const token = config.DISCORD_BOT_TOKEN;
  const applicationId = config.DISCORD_APPLICATION_ID;

  if (!token || !applicationId) {
    logger.debug('[DiscordSlash] Cannot register commands: DISCORD_BOT_TOKEN or DISCORD_APPLICATION_ID not configured.');
    return {
      status: 'NOT_CONFIGURED',
      commandsCount: discordCommands.length,
      registeredNames: discordCommands.map((c) => c.data.name),
      scope: 'NONE',
      error: 'DISCORD_APPLICATION_ID or DISCORD_BOT_TOKEN missing in environment.',
    };
  }

  const rest = new REST({ version: '10' }).setToken(token);
  const commandData = discordCommands.map((c) => c.data.toJSON());

  try {
    if (guildId) {
      // Guild-specific registration (instant updates for development/testing)
      await rest.put(
        Routes.applicationGuildCommands(applicationId, guildId),
        { body: commandData }
      );

      // Query Discord REST API to verify commands exist on Discord
      const verifiedRemote = (await rest.get(
        Routes.applicationGuildCommands(applicationId, guildId)
      )) as any[];

      const registeredNames = Array.isArray(verifiedRemote) ? verifiedRemote.map((cmd: any) => cmd.name) : [];
      logger.info(`[DiscordSlash] Successfully registered and verified ${registeredNames.length} guild slash commands for guild ${guildId}`);

      return {
        status: 'SUCCESS',
        commandsCount: registeredNames.length,
        registeredNames,
        scope: 'GUILD',
      };
    } else {
      // Global registration
      await rest.put(
        Routes.applicationCommands(applicationId),
        { body: commandData }
      );

      // Query Discord REST API to verify global commands exist on Discord
      const verifiedRemote = (await rest.get(
        Routes.applicationCommands(applicationId)
      )) as any[];

      const registeredNames = Array.isArray(verifiedRemote) ? verifiedRemote.map((cmd: any) => cmd.name) : [];
      logger.info(`[DiscordSlash] Successfully registered and verified ${registeredNames.length} global slash commands`);

      return {
        status: 'SUCCESS',
        commandsCount: registeredNames.length,
        registeredNames,
        scope: 'GLOBAL',
      };
    }
  } catch (err) {
    logger.error('[DiscordSlash] Failed to register slash commands:', undefined, {
      error: (err as Error).message,
    });
    return {
      status: 'FAILED',
      commandsCount: 0,
      registeredNames: [],
      scope: guildId ? 'GUILD' : 'GLOBAL',
      error: (err as Error).message,
    };
  }
}
