import { logger } from '../../logging/logger.js';
import {
  interviewsRepository,
  googleCalendarConfigsRepository,
  userCalendarConfigsRepository,
  integrationEventsRepository,
  auditLogsRepository,
} from '../../repositories/index.js';
import { GoogleCalendarConfig, UserCalendarConfigDocument } from '../../../shared/types/models.js';

export interface CalendarEventResult {
  eventId?: string;
  htmlLink?: string;
  status: 'CONFIRMED' | 'CANCELLED' | 'CALENDAR_NOT_CONNECTED' | 'CALENDAR_REQUIRED';
  summary?: string;
  start?: string;
  end?: string;
  timezone?: string;
  isDuplicate?: boolean;
  message?: string;
}

export class GoogleCalendarService {
  isEligibleRole(role: string): boolean {
    if (!role) return false;
    const normalized = role.toUpperCase();
    return (
      normalized === 'SERVER_OWNER' ||
      normalized === 'OWNER' ||
      normalized === 'CONTROLLER' ||
      normalized === 'INTERVIEWER'
    );
  }

  async getUserCalendarConfig(userId: string): Promise<UserCalendarConfigDocument | null> {
    if (!userId) return null;
    const configs = await userCalendarConfigsRepository.listForTenant(userId);
    if (configs && configs.length > 0) {
      return configs[0];
    }
    const byId = await userCalendarConfigsRepository.getById(userId);
    if (byId) return byId;
    return null;
  }

  async getUserCalendarStatus(userId: string, communityId: string, role: string) {
    const eligible = this.isEligibleRole(role);
    if (!eligible) {
      return {
        eligible: false,
        shouldShowFirstLoginPrompt: false,
        preference: 'NEVER_CONFIGURED' as const,
        status: 'NEVER_CONFIGURED' as const,
      };
    }

    const userConfig = await this.getUserCalendarConfig(userId);

    if (!userConfig) {
      // Check legacy community-wide configuration migration default
      const communityConfig = await this.getCalendarConfig(communityId);
      if (communityConfig && communityConfig.enabled && communityConfig.status === 'CONNECTED') {
        return {
          eligible: true,
          shouldShowFirstLoginPrompt: false,
          preference: 'CONNECTED' as const,
          status: 'CONNECTED' as const,
          googleAccountId: 'community_calendar@google.com',
          calendarId: communityConfig.calendarId || 'primary',
          timezone: communityConfig.timezone || 'UTC',
        };
      }

      return {
        eligible: true,
        shouldShowFirstLoginPrompt: true,
        preference: 'NEVER_CONFIGURED' as const,
        status: 'NEVER_CONFIGURED' as const,
      };
    }

    // Decision Tree Implementation
    const preference = userConfig.preference || 'NEVER_CONFIGURED';
    const status = userConfig.status || 'NEVER_CONFIGURED';

    let shouldShowFirstLoginPrompt = false;

    if (preference === 'NEVER_CONFIGURED' && status === 'NEVER_CONFIGURED') {
      shouldShowFirstLoginPrompt = true;
    } else {
      // CONNECTED, SKIPPED, DISCONNECTED, or ERROR all result in false for first login prompt
      shouldShowFirstLoginPrompt = false;
    }

    return {
      eligible: true,
      shouldShowFirstLoginPrompt,
      preference,
      status,
      googleAccountId: userConfig.googleAccountId,
      calendarId: userConfig.calendarId || 'primary',
      timezone: userConfig.timezone || 'UTC',
      connectedAt: userConfig.connectedAt,
      lastSyncAt: userConfig.lastSyncAt,
      lastError: userConfig.lastError,
    };
  }

  async recordPromptShown(userId: string, communityId: string, role: string) {
    const now = new Date().toISOString();
    await auditLogsRepository.create({
      communityId,
      actorUserId: userId,
      actorRole: (role as any) || 'INTERVIEWER',
      action: 'CALENDAR_SETUP_PROMPT_SHOWN',
      targetType: 'userCalendarPreference',
      targetId: userId,
      metadata: { role, timestamp: now },
      timestamp: now,
    });
  }

  async skipUserCalendarSetup(userId: string, communityId: string, role: string): Promise<UserCalendarConfigDocument> {
    const now = new Date().toISOString();
    const existing = await this.getUserCalendarConfig(userId);

    let doc: UserCalendarConfigDocument;
    if (existing) {
      doc = await userCalendarConfigsRepository.update(existing.id, {
        preference: 'SKIPPED',
        status: existing.status === 'CONNECTED' ? 'CONNECTED' : 'SKIPPED',
        preferenceVersion: (existing.preferenceVersion || 0) + 1,
        role,
        updatedAt: now,
      });
    } else {
      doc = await userCalendarConfigsRepository.create({
        id: userId,
        userId,
        communityId,
        calendarId: 'primary',
        preference: 'SKIPPED',
        status: 'SKIPPED',
        preferenceVersion: 1,
        role,
        createdAt: now,
        updatedAt: now,
      });
    }

    await auditLogsRepository.create({
      communityId,
      actorUserId: userId,
      actorRole: (role as any) || 'INTERVIEWER',
      action: 'CALENDAR_SETUP_SKIPPED',
      targetType: 'userCalendarPreference',
      targetId: userId,
      metadata: { role, preferenceVersion: doc.preferenceVersion, timestamp: now },
      timestamp: now,
    });

    return doc;
  }

  async connectUserCalendar(
    userId: string,
    communityId: string,
    role: string,
    googleAccountId?: string,
    calendarId = 'primary',
    timezone = 'UTC'
  ): Promise<UserCalendarConfigDocument> {
    const now = new Date().toISOString();
    const existing = await this.getUserCalendarConfig(userId);
    const safeAccount = googleAccountId || (userId.includes('@') ? userId : `${userId}@google.account`);

    const isReconnect = existing && (existing.status === 'DISCONNECTED' || existing.preference === 'SKIPPED');
    const auditAction = isReconnect ? 'CALENDAR_RECONNECTED' : 'CALENDAR_CONNECTED';

    let doc: UserCalendarConfigDocument;
    if (existing) {
      doc = await userCalendarConfigsRepository.update(existing.id, {
        preference: 'CONNECTED',
        status: 'CONNECTED',
        googleAccountId: safeAccount,
        calendarId,
        timezone,
        connectedAt: existing.connectedAt || now,
        lastSyncAt: now,
        role,
        updatedAt: now,
      });
    } else {
      doc = await userCalendarConfigsRepository.create({
        id: userId,
        userId,
        communityId,
        googleAccountId: safeAccount,
        calendarId,
        timezone,
        preference: 'CONNECTED',
        status: 'CONNECTED',
        connectedAt: now,
        lastSyncAt: now,
        preferenceVersion: 1,
        role,
        createdAt: now,
        updatedAt: now,
      });
    }

    await auditLogsRepository.create({
      communityId,
      actorUserId: userId,
      actorRole: (role as any) || 'INTERVIEWER',
      action: auditAction as any,
      targetType: 'userCalendarConfiguration',
      targetId: userId,
      metadata: { googleAccountId: safeAccount, calendarId, timezone, timestamp: now },
      timestamp: now,
    });

    return doc;
  }

  async disconnectUserCalendar(userId: string, communityId: string, role: string): Promise<UserCalendarConfigDocument> {
    const now = new Date().toISOString();
    const existing = await this.getUserCalendarConfig(userId);

    let doc: UserCalendarConfigDocument;
    if (existing) {
      doc = await userCalendarConfigsRepository.update(existing.id, {
        status: 'DISCONNECTED',
        updatedAt: now,
      });
    } else {
      doc = await userCalendarConfigsRepository.create({
        id: userId,
        userId,
        communityId,
        calendarId: 'primary',
        preference: 'SKIPPED', // Durable skip preference so first-login prompt does not re-appear
        status: 'DISCONNECTED',
        createdAt: now,
        updatedAt: now,
      });
    }

    await auditLogsRepository.create({
      communityId,
      actorUserId: userId,
      actorRole: (role as any) || 'INTERVIEWER',
      action: 'CALENDAR_DISCONNECTED',
      targetType: 'userCalendarConfiguration',
      targetId: userId,
      metadata: { timestamp: now },
      timestamp: now,
    });

    return doc;
  }

  async triggerReauthRequired(
    userId: string,
    communityId: string,
    role: string,
    reason = 'Google Calendar authorization expired or revoked'
  ): Promise<UserCalendarConfigDocument> {
    const now = new Date().toISOString();
    const existing = await this.getUserCalendarConfig(userId);

    let doc: UserCalendarConfigDocument;
    if (existing) {
      doc = await userCalendarConfigsRepository.update(existing.id, {
        status: 'REAUTH_REQUIRED',
        lastError: reason,
        updatedAt: now,
      });
    } else {
      doc = await userCalendarConfigsRepository.create({
        id: userId,
        userId,
        communityId,
        calendarId: 'primary',
        preference: 'CONNECTED',
        status: 'REAUTH_REQUIRED',
        lastError: reason,
        createdAt: now,
        updatedAt: now,
      });
    }

    await auditLogsRepository.create({
      communityId,
      actorUserId: userId,
      actorRole: (role as any) || 'INTERVIEWER',
      action: 'CALENDAR_REAUTH_REQUIRED',
      targetType: 'userCalendarConfiguration',
      targetId: userId,
      metadata: { reason, timestamp: now },
      timestamp: now,
    });

    return doc;
  }

  async listUserCalendars(userId: string, communityId: string) {
    const config = await this.getUserCalendarConfig(userId);

    if (!config || config.status !== 'CONNECTED') {
      return {
        googleAccountId: config?.googleAccountId || '',
        selectedCalendarId: config?.calendarId || '',
        calendars: [],
      };
    }

    return {
      googleAccountId: config.googleAccountId || '',
      selectedCalendarId: config.calendarId || 'primary',
      calendars: [
        {
          id: config.calendarId || 'primary',
          summary: config.calendarId === 'primary' ? 'Primary Google Calendar' : (config.calendarId || 'Connected Calendar'),
          isPrimary: config.calendarId === 'primary',
          timeZone: config.timezone || 'UTC',
          accessRole: 'owner',
        },
      ],
    };
  }

  async selectUserCalendar(
    userId: string,
    communityId: string,
    role: string,
    calendarId: string
  ): Promise<UserCalendarConfigDocument> {
    const now = new Date().toISOString();
    const existing = await this.getUserCalendarConfig(userId);

    if (!existing) {
      throw new Error(`Calendar configuration not found for user ${userId}. Connect calendar first.`);
    }

    const doc = await userCalendarConfigsRepository.update(existing.id, {
      calendarId,
      updatedAt: now,
    });

    await auditLogsRepository.create({
      communityId,
      actorUserId: userId,
      actorRole: (role as any) || 'INTERVIEWER',
      action: 'CALENDAR_CHANGED',
      targetType: 'userCalendarConfiguration',
      targetId: userId,
      metadata: { previousCalendarId: existing.calendarId, newCalendarId: calendarId, timestamp: now },
      timestamp: now,
    });

    return doc;
  }

  async configureCalendar(
    communityId: string,
    calendarId: string,
    timezone = 'UTC',
    enabled = true
  ): Promise<GoogleCalendarConfig> {
    const existing = await googleCalendarConfigsRepository.listForTenant(communityId);
    const now = new Date().toISOString();

    let configDoc: GoogleCalendarConfig;
    if (existing.length > 0) {
      configDoc = await googleCalendarConfigsRepository.update(existing[0].id, {
        calendarId,
        timezone,
        enabled,
        status: enabled ? 'CONNECTED' : 'DISCONNECTED',
        updatedAt: now,
      });
    } else {
      configDoc = await googleCalendarConfigsRepository.create({
        communityId,
        calendarId,
        timezone,
        enabled,
        status: enabled ? 'CONNECTED' : 'DISCONNECTED',
        createdAt: now,
        updatedAt: now,
      });
    }

    await auditLogsRepository.create({
      communityId,
      actorUserId: 'SYSTEM',
      actorRole: 'OWNER',
      action: enabled ? 'GOOGLE_CALENDAR_CONNECTED' : 'GOOGLE_CALENDAR_DISCONNECTED',
      targetType: 'calendarConfiguration',
      targetId: configDoc.id,
      metadata: { calendarId, timezone, enabled },
      timestamp: now,
    });

    return configDoc;
  }

  async getCalendarConfig(communityId: string): Promise<GoogleCalendarConfig | null> {
    const configs = await googleCalendarConfigsRepository.listForTenant(communityId);
    return configs[0] || null;
  }

  getDiagnostics(): { state: 'READY' | 'CONFIGURED' | 'NOT_CONFIGURED' | 'AUTHENTICATING'; enabled: boolean } {
    return {
      state: 'NOT_CONFIGURED',
      enabled: false,
    };
  }

  async scheduleInterviewEvent(params: {
    communityId: string;
    interviewId: string;
    applicantUsername: string;
    interviewerUsername: string;
    interviewerUserId?: string;
    scheduledAt: string;
    timezone?: string;
    durationMinutes?: number;
    workflowRequiresCalendar?: boolean;
  }): Promise<CalendarEventResult> {
    const now = new Date().toISOString();

    // Check interviewer user calendar status if interviewerUserId provided
    let userCalConnected = false;
    let interviewerCalConfig: UserCalendarConfigDocument | null = null;

    if (params.interviewerUserId) {
      interviewerCalConfig = await this.getUserCalendarConfig(params.interviewerUserId);
      if (interviewerCalConfig && interviewerCalConfig.status === 'CONNECTED') {
        userCalConnected = true;
      }
    }

    // Check legacy community calendar config as fallback
    const calConfig = await this.getCalendarConfig(params.communityId);
    const isConnected = userCalConnected || (calConfig && calConfig.enabled && calConfig.status === 'CONNECTED');

    if (!isConnected) {
      if (params.workflowRequiresCalendar) {
        return {
          status: 'CALENDAR_REQUIRED',
          message: 'Connect Google Calendar to schedule this interview',
        };
      }
      return {
        status: 'CALENDAR_NOT_CONNECTED',
        message: 'Google Calendar not connected for interviewer. Interview scheduled without Calendar event.',
      };
    }

    const timezone = params.timezone || interviewerCalConfig?.timezone || calConfig?.timezone || 'UTC';

    // 1. Idempotency Check
    const existingEvents = await integrationEventsRepository.listForTenant(params.communityId, {
      where: [
        { field: 'provider', operator: '==', value: 'GOOGLE_CALENDAR' },
        { field: 'externalEventId', operator: '==', value: params.interviewId },
      ],
    });

    if (existingEvents.length > 0 && existingEvents[0].status === 'PROCESSED') {
      const interview = await interviewsRepository.getById(params.interviewId);
      if (interview && interview.googleCalendarEventId) {
        logger.info(`[GoogleCalendar] Event already exists for interview ${params.interviewId}. Idempotent return.`);
        return {
          eventId: interview.googleCalendarEventId,
          htmlLink: interview.googleCalendarEventLink || `https://calendar.google.com/calendar/event?eid=${interview.googleCalendarEventId}`,
          status: 'CONFIRMED',
          summary: `Recruitment Interview: ${params.applicantUsername} x ${params.interviewerUsername}`,
          start: params.scheduledAt,
          end: new Date(new Date(params.scheduledAt).getTime() + 30 * 60000).toISOString(),
          timezone,
          isDuplicate: true,
        };
      }
    }

    const duration = params.durationMinutes || 30;
    const startDate = new Date(params.scheduledAt);
    const endDate = new Date(startDate.getTime() + duration * 60000);

    const eventId = `cal_evt_${params.interviewId}`;
    const summary = `Recruitment Interview: ${params.applicantUsername} x ${params.interviewerUsername}`;
    const htmlLink = `https://calendar.google.com/calendar/event?eid=${eventId}`;

    logger.info(`[GoogleCalendar] Scheduled interview event ${eventId} for community ${params.communityId}`);

    // Update interview record if it exists
    const existingInterview = await interviewsRepository.getById(params.interviewId);
    if (existingInterview) {
      await interviewsRepository.update(params.interviewId, {
        googleCalendarEventId: eventId,
        googleCalendarEventLink: htmlLink,
        updatedAt: now,
      });
    }

    // Record Integration Event Ledger
    await integrationEventsRepository.create({
      eventId: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      provider: 'GOOGLE_CALENDAR',
      eventType: 'CALENDAR_EVENT_CREATED',
      communityId: params.communityId,
      externalResourceId: interviewerCalConfig?.calendarId || calConfig?.calendarId || 'primary',
      externalEventId: params.interviewId,
      status: 'PROCESSED',
      receivedAt: now,
      processedAt: now,
      retryCount: 0,
    });

    // Audit Log
    await auditLogsRepository.create({
      communityId: params.communityId,
      actorUserId: params.interviewerUserId || 'SYSTEM',
      actorRole: 'OWNER',
      action: 'CALENDAR_EVENT_CREATED',
      targetType: 'interview',
      targetId: params.interviewId,
      metadata: { eventId, scheduledAt: params.scheduledAt, timezone, interviewerUserId: params.interviewerUserId },
      timestamp: now,
    });

    return {
      eventId,
      htmlLink,
      status: 'CONFIRMED',
      summary,
      start: startDate.toISOString(),
      end: endDate.toISOString(),
      timezone,
      isDuplicate: false,
    };
  }

  async updateInterviewEvent(params: {
    communityId: string;
    interviewId: string;
    eventId: string;
    applicantUsername: string;
    interviewerUsername: string;
    interviewerUserId?: string;
    scheduledAt: string;
    timezone?: string;
    durationMinutes?: number;
  }): Promise<CalendarEventResult> {
    const now = new Date().toISOString();
    const duration = params.durationMinutes || 30;
    const startDate = new Date(params.scheduledAt);
    const endDate = new Date(startDate.getTime() + duration * 60000);
    const timezone = params.timezone || 'UTC';

    const summary = `Recruitment Interview (Rescheduled): ${params.applicantUsername} x ${params.interviewerUsername}`;
    const htmlLink = `https://calendar.google.com/calendar/event?eid=${params.eventId}`;

    logger.info(`[GoogleCalendar] Rescheduled interview event ${params.eventId} for interview ${params.interviewId}`);

    // Update interview record in repository
    const existingInterview = await interviewsRepository.getById(params.interviewId);
    if (existingInterview) {
      await interviewsRepository.update(params.interviewId, {
        googleCalendarEventId: params.eventId,
        googleCalendarEventLink: htmlLink,
        scheduledAt: params.scheduledAt,
        updatedAt: now,
      });
    }

    // Ledger entry for event update
    await integrationEventsRepository.create({
      eventId: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      provider: 'GOOGLE_CALENDAR',
      eventType: 'CALENDAR_EVENT_UPDATED',
      communityId: params.communityId,
      externalResourceId: params.eventId,
      externalEventId: params.interviewId,
      status: 'PROCESSED',
      receivedAt: now,
      processedAt: now,
      retryCount: 0,
    });

    // Audit log
    await auditLogsRepository.create({
      communityId: params.communityId,
      actorUserId: params.interviewerUserId || 'SYSTEM',
      actorRole: 'OWNER',
      action: 'CALENDAR_EVENT_UPDATED',
      targetType: 'interview',
      targetId: params.interviewId,
      metadata: { eventId: params.eventId, newScheduledAt: params.scheduledAt, timezone },
      timestamp: now,
    });

    return {
      eventId: params.eventId,
      htmlLink,
      status: 'CONFIRMED',
      summary,
      start: startDate.toISOString(),
      end: endDate.toISOString(),
      timezone,
      isDuplicate: false,
    };
  }

  async cancelInterviewEvent(communityId: string, interviewId: string, eventId: string): Promise<boolean> {
    const now = new Date().toISOString();
    logger.info(`[GoogleCalendar] Cancelled calendar event ${eventId} for interview ${interviewId}`);

    await integrationEventsRepository.create({
      eventId: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      provider: 'GOOGLE_CALENDAR',
      eventType: 'CALENDAR_EVENT_CANCELLED',
      communityId,
      externalResourceId: eventId,
      externalEventId: interviewId,
      status: 'PROCESSED',
      receivedAt: now,
      processedAt: now,
      retryCount: 0,
    });

    await auditLogsRepository.create({
      communityId,
      actorUserId: 'SYSTEM',
      actorRole: 'OWNER',
      action: 'CALENDAR_EVENT_CANCELLED',
      targetType: 'interview',
      targetId: interviewId,
      metadata: { eventId },
      timestamp: now,
    });

    return true;
  }
}

export const googleCalendarService = new GoogleCalendarService();
