import { Firestore } from '@google-cloud/firestore';
import { config } from './env.js';
import { sanitizeFirestoreDatabaseId, getFirestoreDb as getRepositoryFirestoreDb } from '../repositories/firestore.repository.js';

let dbInstance: Firestore | null = null;

export function getFirestoreDb(): Firestore {
  if (dbInstance) return dbInstance;
  const instance = getRepositoryFirestoreDb();
  if (instance) {
    dbInstance = instance;
    return dbInstance;
  }
  const projectId = config.GOOGLE_CLOUD_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT || process.env.GCP_PROJECT || 'community-manager-bot-508316';
  const databaseId = sanitizeFirestoreDatabaseId(config.FIRESTORE_DATABASE_ID);
  
  dbInstance = new Firestore({
    projectId,
    ...(databaseId ? { databaseId } : {}),
  });
  return dbInstance;
}

export const db = getFirestoreDb();
