import { AppConfig } from './env.js';
import { logger } from '../logging/logger.js';

export interface EnvironmentValidationResult {
  valid: boolean;
  environment: 'development' | 'test' | 'staging' | 'production';
  missingRequired: string[];
  configuredOptional: string[];
  unconfiguredOptional: string[];
  errors: string[];
}

export function validateEnvironment(config: AppConfig): EnvironmentValidationResult {
  const env = config.APP_ENV || config.NODE_ENV;
  const missingRequired: string[] = [];
  const configuredOptional: string[] = [];
  const unconfiguredOptional: string[] = [];
  const errors: string[] = [];

  // 1. Mandatory base variables in all environments
  if (!config.PORT || isNaN(config.PORT) || config.PORT <= 0 || config.PORT > 65535) {
    missingRequired.push('PORT (must be a valid port number 1-65535)');
  }
  if (!config.APP_URL) missingRequired.push('APP_URL');

  // 2. Production / Staging Environment Validation
  if (config.APP_RUNTIME_MODE === 'PRODUCTION' || config.APP_RUNTIME_MODE === 'REAL_DISCORD_PREVIEW') {
    if (!config.DISCORD_BOT_TOKEN) {
      errors.push('STARTUP_FAILURE: DISCORD_BOT_TOKEN is mandatory for production operations.');
    }
    if (!config.DISCORD_APPLICATION_ID && !config.DISCORD_CLIENT_ID) {
      errors.push('STARTUP_FAILURE: DISCORD_APPLICATION_ID or DISCORD_CLIENT_ID is mandatory for production operations.');
    }
    if (!config.GOOGLE_CLOUD_PROJECT_ID && !config.FIRESTORE_DATABASE_ID) {
      errors.push('STARTUP_FAILURE: GOOGLE_CLOUD_PROJECT_ID or FIRESTORE_DATABASE_ID is required.');
    }
  } else if (config.APP_RUNTIME_MODE === 'DEVELOPMENT_SIMULATION') {
    // Ensure the simulation provider is available and configured
    const hasSimulationProvider = true;
    if (!hasSimulationProvider) {
      errors.push('STARTUP_FAILURE: DEVELOPMENT_SIMULATION mode is active but the required simulation provider is missing.');
    }
  }

  if (env === 'production' || env === 'staging') {
    if (!config.SESSION_SECRET || config.SESSION_SECRET.trim().length < 32 || config.SESSION_SECRET === 'community-manager-session-secret-dev-safe') {
      missingRequired.push('SESSION_SECRET');
    }

    // Database verification
    if (!config.GOOGLE_CLOUD_PROJECT_ID && !config.FIRESTORE_DATABASE_ID) {
      missingRequired.push('GOOGLE_CLOUD_PROJECT_ID or FIRESTORE_DATABASE_ID');
    }

    // Platform Owner Email verification (No hardcoded fallbacks in production)
    if (!config.PLATFORM_OWNER_EMAIL || config.PLATFORM_OWNER_EMAIL.includes('example.com')) {
      missingRequired.push('PLATFORM_OWNER_EMAIL');
    }
  }

  // 3. Integration Status Classifications (Optional integrations default to NOT_CONFIGURED)
  if (config.DISCORD_BOT_TOKEN) {
    configuredOptional.push('Discord Bot');
  } else {
    unconfiguredOptional.push('Discord Bot');
  }

  if (config.DISCORD_CLIENT_ID && config.DISCORD_CLIENT_SECRET) {
    configuredOptional.push('Discord OAuth');
  } else {
    unconfiguredOptional.push('Discord OAuth');
  }

  if (config.AI_API_KEY || config.GEMINI_API_KEY) {
    configuredOptional.push('Community Brain AI');
  } else {
    unconfiguredOptional.push('Community Brain AI');
  }

  if (config.STRIPE_SECRET_KEY && config.STRIPE_WEBHOOK_SECRET) {
    configuredOptional.push('Billing Provider (Stripe)');
  } else {
    unconfiguredOptional.push('Billing Provider (Stripe)');
  }

  if (config.GOOGLE_SHEETS_SPREADSHEET_ID) {
    configuredOptional.push('Google Sheets');
  } else {
    unconfiguredOptional.push('Google Sheets');
  }

  const isValid = missingRequired.length === 0 && errors.length === 0;

  const result: EnvironmentValidationResult = {
    valid: isValid,
    environment: env,
    missingRequired,
    configuredOptional,
    unconfiguredOptional,
    errors,
  };

  if (!isValid) {
    const errorMsg = `[ENV_VALIDATION] Environment notice for '${env}':\n` +
      (missingRequired.length ? ` - Missing Optional/Required Variables: ${missingRequired.join(', ')}\n` : '') +
      (errors.length ? ` - Configuration Notices: ${errors.join('; ')}\n` : '');

    logger.warn(errorMsg);
  } else {
    logger.info(`[ENV_VALIDATION] Environment '${env}' validated successfully. Configured optional integrations: [${configuredOptional.join(', ')}]. Unconfigured: [${unconfiguredOptional.join(', ')}].`);
  }

  return result;
}
