import dotenv from 'dotenv';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { validateEnvironment } from './envValidation.js';

// Load .env first if it exists
dotenv.config();

// Fallback load .env.example so manually updated settings are picked up
try {
  const envExamplePath = path.resolve(process.cwd(), '.env.example');
  if (fs.existsSync(envExamplePath)) {
    const rawContent = fs.readFileSync(envExamplePath, 'utf8');
    const parsed = dotenv.parse(rawContent);
    for (const key of Object.keys(parsed)) {
      const val = parsed[key]?.trim();
      if (val && (!process.env[key] || process.env[key]?.trim() === '')) {
        process.env[key] = val;
      }
    }
  }
} catch {
  // Ignore fallback load error
}

export class ConfigurationError extends Error {
  public code: string;
  constructor(message: string, code: string = 'CONFIGURATION_ERROR') {
    super(message);
    this.name = 'ConfigurationError';
    this.code = code;
  }
}

export function validateProductionConfig(config: AppConfig, options?: { requireFirestore?: boolean }): void {
  if (config.APP_RUNTIME_MODE === 'PRODUCTION' || config.APP_RUNTIME_MODE === 'REAL_DISCORD_PREVIEW') {
    if (!config.SESSION_SECRET || config.SESSION_SECRET.trim().length < 32 || config.SESSION_SECRET === 'community-manager-session-secret-dev-safe') {
      throw new ConfigurationError('CONFIGURATION_ERROR: SESSION_SECRET is required in production modes and must be at least 32 characters long.', 'INVALID_SESSION_SECRET');
    }
    if (!config.DISCORD_BOT_TOKEN || config.DISCORD_BOT_TOKEN.trim() === '') {
      throw new ConfigurationError('CONFIGURATION_ERROR: DISCORD_BOT_TOKEN is required in production modes.', 'MISSING_DISCORD_BOT_TOKEN');
    }
    if (!config.DISCORD_CLIENT_SECRET || config.DISCORD_CLIENT_SECRET.trim() === '') {
      throw new ConfigurationError('CONFIGURATION_ERROR: DISCORD_CLIENT_SECRET is required in production modes.', 'MISSING_DISCORD_CLIENT_SECRET');
    }
    if (!config.DISCORD_APPLICATION_ID && !config.DISCORD_CLIENT_ID) {
      throw new ConfigurationError('CONFIGURATION_ERROR: DISCORD_APPLICATION_ID or DISCORD_CLIENT_ID is required in production modes.', 'MISSING_DISCORD_CLIENT_ID');
    }
    if (!config.DISCORD_REDIRECT_URI || (!config.DISCORD_REDIRECT_URI.startsWith('http://') && !config.DISCORD_REDIRECT_URI.startsWith('https://'))) {
      throw new ConfigurationError('CONFIGURATION_ERROR: DISCORD_REDIRECT_URI must be a valid absolute URL in production modes.', 'INVALID_DISCORD_REDIRECT_URI');
    }
    if (options?.requireFirestore || config.APP_RUNTIME_MODE === 'PRODUCTION') {
      const explicitGcp = (config as any).GCP_PROJECT_ID;
      const gcpProject = explicitGcp !== undefined ? explicitGcp : (config.GOOGLE_CLOUD_PROJECT_ID || '');
      if (!gcpProject || gcpProject.trim() === '') {
        throw new ConfigurationError('CONFIGURATION_ERROR: GOOGLE_CLOUD_PROJECT_ID is required in production modes.', 'MISSING_GCP_PROJECT_ID');
      }
      if (!config.FIRESTORE_DATABASE_ID || config.FIRESTORE_DATABASE_ID.trim() === '') {
        throw new ConfigurationError('CONFIGURATION_ERROR: FIRESTORE_DATABASE_ID is required in PRODUCTION mode.', 'MISSING_FIRESTORE_DATABASE_ID');
      }
    }
  }
}

export interface AppConfig {
  NODE_ENV: 'development' | 'production' | 'test' | 'staging';
  APP_ENV: 'development' | 'production' | 'test' | 'staging';
  PORT: number;
  APP_URL: string;
  DISCORD_OAUTH_CALLBACK_URL: string;
  BOT_SINGLE_RUNTIME_ENABLED: boolean;

  // Free-First Architecture Controls
  FREE_MODE: boolean;
  MAX_AI_REQUESTS_PER_DAY: number;
  MAX_APPLICATIONS_PER_DAY: number;
  MAX_SHEET_WRITES_PER_DAY: number;
  MAX_AI_TOKENS_PER_REQUEST: number;

  // Session & Security
  SESSION_SECRET?: string;

  // Discord Bot & OAuth
  DISCORD_BOT_TOKEN?: string;
  DISCORD_APPLICATION_ID?: string;
  DISCORD_CLIENT_ID?: string;
  DISCORD_CLIENT_SECRET?: string;
  DISCORD_REDIRECT_URI?: string;
  DISCORD_PUBLIC_KEY?: string;

  // Google Cloud & Firestore
  GOOGLE_CLOUD_PROJECT_ID?: string;
  GOOGLE_CLOUD_REGION?: string;
  FIRESTORE_DATABASE_ID?: string;

  // Community Brain AI & Sheets
  AI_API_KEY?: string;
  GEMINI_API_KEY?: string;
  GOOGLE_SHEETS_SPREADSHEET_ID?: string;

  // Billing Provider Controls
  STRIPE_SECRET_KEY?: string;
  STRIPE_WEBHOOK_SECRET?: string;

  // Platform Administration (Configurable - never hardcoded in production)
  PLATFORM_OWNER_USER_ID?: string;
  PLATFORM_OWNER_EMAIL?: string;
  PLATFORM_ADMIN_KEY?: string;

  // Development Seeding Controls
  COMMUNITY_DEV_SEEDING_ENABLED: boolean;

  // Development Simulation Enabled
  DEV_SIMULATION_ENABLED: boolean;

  // Release Lock Control
  PRODUCT_RELEASE_LOCKED: boolean;

  // Runtime operational mode
  APP_RUNTIME_MODE: 'DEVELOPMENT_SIMULATION' | 'REAL_DISCORD_PREVIEW' | 'PRODUCTION';
}

export function loadConfig(): AppConfig {
  const nodeEnv = (process.env.NODE_ENV as 'development' | 'production' | 'test' | 'staging') || 'development';
  const appEnv = (process.env.APP_ENV as 'development' | 'production' | 'test' | 'staging') || nodeEnv;
  const isProdOrStaging = appEnv === 'production' || appEnv === 'staging' || nodeEnv === 'production' || nodeEnv === 'staging';

  const rawRuntimeMode = process.env.APP_RUNTIME_MODE;
  let resolvedRuntimeMode: 'DEVELOPMENT_SIMULATION' | 'REAL_DISCORD_PREVIEW' | 'PRODUCTION' = 'PRODUCTION';

  if (rawRuntimeMode === 'development' || rawRuntimeMode === 'DEVELOPMENT_SIMULATION') {
    resolvedRuntimeMode = 'DEVELOPMENT_SIMULATION';
  } else if (rawRuntimeMode === 'real-preview' || rawRuntimeMode === 'REAL_DISCORD_PREVIEW') {
    resolvedRuntimeMode = 'REAL_DISCORD_PREVIEW';
  } else if (rawRuntimeMode === 'production' || rawRuntimeMode === 'PRODUCTION') {
    resolvedRuntimeMode = 'PRODUCTION';
  } else {
    // Default fallback:
    if (isProdOrStaging) {
      resolvedRuntimeMode = 'PRODUCTION';
    } else {
      resolvedRuntimeMode = 'DEVELOPMENT_SIMULATION';
    }
  }

  // Force simulation completely disabled in REAL_DISCORD_PREVIEW and PRODUCTION
  const devSimulationEnabled = resolvedRuntimeMode === 'DEVELOPMENT_SIMULATION' && process.env.DEV_SIMULATION_ENABLED !== 'false';

  const aiApiKey = process.env.AI_API_KEY || process.env.GEMINI_API_KEY || undefined;
  const parsedPort = Number(process.env.PORT || 3000);

  const sanitizeAppUrl = (url?: string): string | undefined => {
    if (!url) return undefined;
    const trimmed = url.trim();
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) return undefined;
    if (trimmed.includes('discord.com')) return undefined;
    return trimmed.replace(/\/+$/, '');
  };

  // Robustly resolve APP_URL, handling case where Cloud Run URL was placed in SESSION_SECRET or APP_URL had discord.com
  let resolvedAppUrl = sanitizeAppUrl(process.env.APP_URL)
    || sanitizeAppUrl(process.env.CUSTOM_DOMAIN_URL)
    || sanitizeAppUrl(process.env.SESSION_SECRET);

  if (!resolvedAppUrl) {
    if (isProdOrStaging) {
      resolvedAppUrl = sanitizeAppUrl(process.env.AIS_APP_URL) || sanitizeAppUrl(process.env.SHARED_APP_URL) || '';
    } else {
      resolvedAppUrl = `http://localhost:${parsedPort}`;
    }
  }

  // Sanitize SESSION_SECRET (if it was set to a URL, derive a secure cryptographic secret)
  let sessionSecret = process.env.SESSION_SECRET?.trim();
  if (sessionSecret && (sessionSecret.startsWith('http://') || sessionSecret.startsWith('https://'))) {
    sessionSecret = 'cm_sec_' + crypto.createHash('sha256').update(sessionSecret + '_session_salt_prod').digest('hex');
  }
  if (!sessionSecret) {
    sessionSecret = resolvedRuntimeMode === 'PRODUCTION' || resolvedRuntimeMode === 'REAL_DISCORD_PREVIEW'
      ? crypto.randomBytes(32).toString('hex')
      : 'community-manager-session-secret-dev-safe';
  }

  // Sanitize DISCORD_REDIRECT_URI: if empty or contains discord.com, point to /api/v1/auth/callback
  let rawRedirectUri = process.env.DISCORD_REDIRECT_URI?.trim();
  if (rawRedirectUri && rawRedirectUri.includes('discord.com')) {
    rawRedirectUri = undefined;
  }
  const oauthCallbackUrl = (rawRedirectUri && rawRedirectUri.includes('/api/v1/auth/callback'))
    ? rawRedirectUri
    : (resolvedAppUrl ? `${resolvedAppUrl}/api/v1/auth/callback` : '/api/v1/auth/callback');

  const appConfig: AppConfig = {
    NODE_ENV: nodeEnv,
    APP_ENV: appEnv,
    PORT: isNaN(parsedPort) ? 3000 : parsedPort,
    APP_URL: resolvedAppUrl,
    DISCORD_OAUTH_CALLBACK_URL: oauthCallbackUrl,
    BOT_SINGLE_RUNTIME_ENABLED: process.env.BOT_SINGLE_RUNTIME_ENABLED !== 'false',

    // Default to strict FREE_MODE
    FREE_MODE: process.env.FREE_MODE !== 'false',
    MAX_AI_REQUESTS_PER_DAY: parseInt(process.env.MAX_AI_REQUESTS_PER_DAY || '100', 10),
    MAX_APPLICATIONS_PER_DAY: parseInt(process.env.MAX_APPLICATIONS_PER_DAY || '50', 10),
    MAX_SHEET_WRITES_PER_DAY: parseInt(process.env.MAX_SHEET_WRITES_PER_DAY || '200', 10),
    MAX_AI_TOKENS_PER_REQUEST: parseInt(process.env.MAX_AI_TOKENS_PER_REQUEST || '2048', 10),

    SESSION_SECRET: sessionSecret,

    DISCORD_BOT_TOKEN: process.env.DISCORD_BOT_TOKEN?.trim() || undefined,
    DISCORD_APPLICATION_ID: (process.env.DISCORD_APPLICATION_ID?.trim() || process.env.DISCORD_CLIENT_ID?.trim()) || undefined,
    DISCORD_CLIENT_ID: (process.env.DISCORD_CLIENT_ID?.trim() || process.env.DISCORD_APPLICATION_ID?.trim()) || undefined,
    DISCORD_CLIENT_SECRET: process.env.DISCORD_CLIENT_SECRET?.trim() || undefined,
    DISCORD_REDIRECT_URI: process.env.DISCORD_REDIRECT_URI?.trim() || undefined,
    DISCORD_PUBLIC_KEY: process.env.DISCORD_PUBLIC_KEY?.trim() || undefined,

    GOOGLE_CLOUD_PROJECT_ID: (process.env.GOOGLE_CLOUD_PROJECT_ID?.trim() || process.env.GCP_PROJECT?.trim() || process.env.GCLOUD_PROJECT?.trim() || ''),
    GOOGLE_CLOUD_REGION: process.env.GOOGLE_CLOUD_REGION?.trim() || 'asia-southeast1',
    FIRESTORE_DATABASE_ID: (() => {
      let candidate = process.env.FIRESTORE_DATABASE_ID?.trim();
      if (candidate) {
        if (candidate !== '(default)' && candidate.startsWith('(') && candidate.endsWith(')')) {
          candidate = candidate.slice(1, -1).trim();
        }
        if (!candidate.startsWith('http://') && !candidate.startsWith('https://') && !candidate.includes('/')) {
          return candidate;
        }
      }
      return resolvedRuntimeMode === 'DEVELOPMENT_SIMULATION' ? '(default)' : undefined;
    })(),

    AI_API_KEY: aiApiKey?.trim(),
    GEMINI_API_KEY: aiApiKey?.trim(),
    GOOGLE_SHEETS_SPREADSHEET_ID: process.env.GOOGLE_SHEETS_SPREADSHEET_ID?.trim() || undefined,

    STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY?.trim() || undefined,
    STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET?.trim() || undefined,

    PLATFORM_OWNER_USER_ID: process.env.PLATFORM_OWNER_USER_ID?.trim() || '',
    PLATFORM_OWNER_EMAIL: process.env.PLATFORM_OWNER_EMAIL?.trim() || '',
    PLATFORM_ADMIN_KEY: process.env.PLATFORM_ADMIN_KEY?.trim() || (isProdOrStaging ? undefined : 'community-admin-key-default'),

    COMMUNITY_DEV_SEEDING_ENABLED: isProdOrStaging ? false : (process.env.COMMUNITY_DEV_SEEDING_ENABLED === 'true'),
    DEV_SIMULATION_ENABLED: devSimulationEnabled,
    PRODUCT_RELEASE_LOCKED: true,
    APP_RUNTIME_MODE: resolvedRuntimeMode,
  };

  const validationResult = validateEnvironment(appConfig);
  (appConfig as any).startupErrors = validationResult.errors;
  (appConfig as any).isStartupValid = validationResult.valid;

  if (!validationResult.valid && validationResult.errors.length > 0) {
    console.warn('==================================================');
    console.warn('HARDENED FAIL-CLOSED OPERATIONAL STATE ACTIVE');
    console.warn(validationResult.errors.join('\n'));
    console.warn('==================================================');
  }

  return appConfig;
}

export const config = loadConfig();

export function isReleaseLocked(): boolean {
  return config.PRODUCT_RELEASE_LOCKED === true;
}

export function isProductionRuntime(): boolean {
  return config.APP_RUNTIME_MODE === 'PRODUCTION' || config.NODE_ENV === 'production' || config.APP_ENV === 'production';
}

