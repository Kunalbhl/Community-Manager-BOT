import { Request, Response } from 'express';

export function listUsers(req: Request, res: Response) {
  res.json({
    success: true,
    data: [
      {
        id: '1547515985416822884',
        username: 'CommunityManagerBot',
        discriminator: '0000',
        role: 'SYSTEM',
        status: 'ACTIVE',
      },
      {
        id: 'user_owner',
        username: 'GuildOwner',
        role: 'SERVER_OWNER',
        status: 'ACTIVE',
      },
    ],
    requestId: req.id,
  });
}

export function getUser(req: Request, res: Response) {
  const { id } = req.params;
  res.json({
    success: true,
    data: {
      id: id || 'user_owner',
      username: 'GuildOwner',
      role: 'SERVER_OWNER',
      status: 'ACTIVE',
    },
    requestId: req.id,
  });
}

export function updateUserRole(req: Request, res: Response) {
  const { id } = req.params;
  const { role } = req.body;
  res.json({
    success: true,
    message: `User ${id} role updated to ${role || 'MEMBER'}.`,
    data: {
      id,
      role: role || 'MEMBER',
    },
    requestId: req.id,
  });
}
