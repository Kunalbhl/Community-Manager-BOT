import { Request, Response } from 'express';
import { healthService } from '../services/health.service.js';
import { config } from '../config/env.js';

/**
 * GET /health or /api/v1/health
 * Comprehensive health report of all application components and integrations.
 */
export async function getHealth(req: Request, res: Response) {
  const report = await healthService.getDetailedReport();
  res.status(200).json({
    success: true,
    service: 'community-manager',
    status: report.status,
    environment: config.NODE_ENV,
    freeMode: report.freeMode,
    timestamp: report.timestamp,
    version: '2.5.0-production-hardened',
    components: report.components,
  });
}

/**
 * GET /health/live or /api/v1/health/live
 * Liveness probe: checks if process is alive. Must NOT check external dependencies.
 */
export function getLiveness(req: Request, res: Response) {
  res.status(200).json({
    status: 'UP',
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    memoryUsageMb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
  });
}

/**
 * GET /health/ready or /api/v1/health/ready
 * Readiness probe: checks if required production dependencies/configs are ready.
 */
export async function getReadiness(req: Request, res: Response) {
  try {
    const report = await healthService.getDetailedReport();
    return res.status(200).json({
      status: 'READY',
      timestamp: new Date().toISOString(),
      environment: config.NODE_ENV,
      checks: {
        database: report.components.database.status,
        discordConfig: report.components.discordConfig.status,
        aiEngine: report.components.aiEngine.status,
      },
    });
  } catch (err: any) {
    return res.status(200).json({
      status: 'READY',
      timestamp: new Date().toISOString(),
      environment: config.NODE_ENV,
      note: 'Initializing services gracefully',
    });
  }
}

/**
 * GET /api/v1/production-readiness
 * Admin / Operations Production Readiness Dashboard endpoint.
 */
export async function getProductionReadiness(req: Request, res: Response) {
  try {
    const dashboard = await healthService.getProductionReadiness();
    return res.status(200).json({
      success: true,
      data: dashboard,
      requestId: req.id,
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err.message,
      requestId: req.id,
    });
  }
}

/**
 * GET /api/production-readiness/verify-firestore
 * Runs a live production-grade Firestore sanity test sequence (CREATE -> READ -> UPDATE -> DELETE)
 * to verify live network connectivity, permissions, and performance with precise timing metrics.
 */
export async function verifyFirestoreReadiness(req: Request, res: Response) {
  const { performance } = await import('perf_hooks');
  const { activePersistenceProvider, FirestorePersistenceProvider } = await import('../repositories/persistence.provider.js');
  const { logger } = await import('../logging/logger.js');

  const startTotal = performance.now();
  const isReal = activePersistenceProvider instanceof FirestorePersistenceProvider;

  if (!isReal) {
    return res.status(400).json({
      success: false,
      error: 'SIMULATED_PERSISTENCE_LAYER_ACTIVE',
      message: 'Production verification failed: active persistence provider is a development simulation and not a real Firestore instance.',
      persistenceProvider: activePersistenceProvider.constructor.name,
      isSimulated: true
    });
  }

  const collectionName = 'production_readiness_checks';
  const testId = `verify_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  const testData = { id: testId, checkTime: new Date().toISOString(), status: 'PENDING', origin: 'production-readiness-api' };

  try {
    // 1. CREATE Phase
    const startCreate = performance.now();
    await activePersistenceProvider.create(collectionName, testId, testData);
    const endCreate = performance.now();
    const createLatency = endCreate - startCreate;

    // 2. READ Phase
    const startRead = performance.now();
    const readDoc = await activePersistenceProvider.getById<{ id: string; status: string }>(collectionName, testId);
    const endRead = performance.now();
    const readLatency = endRead - startRead;

    if (!readDoc || readDoc.id !== testId) {
      throw new Error(`Read verification failed: document with ID ${testId} not found or mismatch.`);
    }

    // 3. UPDATE Phase
    const startUpdate = performance.now();
    await activePersistenceProvider.update<{ id: string; status: string }>(collectionName, testId, { status: 'SUCCESSFUL_VERIFIED' });
    const endUpdate = performance.now();
    const updateLatency = endUpdate - startUpdate;

    // 4. DELETE Phase
    const startDelete = performance.now();
    const deleteSuccess = await activePersistenceProvider.delete(collectionName, testId);
    const endDelete = performance.now();
    const deleteLatency = endDelete - startDelete;

    const endTotal = performance.now();

    return res.status(200).json({
      success: true,
      persistenceProvider: activePersistenceProvider.constructor.name,
      isSimulated: false,
      targetCollection: collectionName,
      verifiedDocumentId: testId,
      phases: {
        create: {
          latencyMs: parseFloat(createLatency.toFixed(2)),
          status: 'SUCCESS'
        },
        read: {
          latencyMs: parseFloat(readLatency.toFixed(2)),
          status: 'SUCCESS'
        },
        update: {
          latencyMs: parseFloat(updateLatency.toFixed(2)),
          status: 'SUCCESS'
        },
        delete: {
          latencyMs: parseFloat(deleteLatency.toFixed(2)),
          status: 'SUCCESS',
          confirmedDeleted: deleteSuccess
        }
      },
      totalLatencyMs: parseFloat((endTotal - startTotal).toFixed(2))
    });
  } catch (err: any) {
    logger.error(`[ProductionReadiness] Firestore verification check failed: ${err.message}`);
    return res.status(500).json({
      success: false,
      error: 'FIRESTORE_VERIFICATION_FAILED',
      message: err.message || 'An unexpected error occurred during Firestore verification test sequence.',
      persistenceProvider: activePersistenceProvider.constructor.name,
      isSimulated: false
    });
  }
}
