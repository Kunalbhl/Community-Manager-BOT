import { Request, Response, NextFunction } from 'express';
import { observabilityService } from '../services/observability/observability.service.js';
import { DiscordRecoveryHelper } from '../services/observability/discordRecovery.js';
import { ForbiddenError, BadRequestError } from '../utils/errors.js';
import { isPlatformOwner } from '../security/rbac.js';

export async function getSystemHealth(req: Request, res: Response, next: NextFunction) {
  try {
    const user = req.user;
    if (!user) throw new ForbiddenError('Authentication required');

    // Platform operator check
    if (!isPlatformOwner(user)) {
      throw new ForbiddenError('Access restricted to Platform Operators');
    }

    const health = await observabilityService.getSystemHealthOverview();
    const discordDiag = DiscordRecoveryHelper.diagnose(
      Boolean(process.env.DISCORD_BOT_TOKEN),
      true
    );

    res.json({
      success: true,
      data: {
        health,
        discordDiagnostic: discordDiag,
      },
      requestId: req.id,
    });
  } catch (error) {
    next(error);
  }
}

export async function getIncidents(req: Request, res: Response, next: NextFunction) {
  try {
    const user = req.user;
    if (!user) throw new ForbiddenError('Authentication required');
    if (!isPlatformOwner(user)) {
      throw new ForbiddenError('Access restricted to Platform Operators');
    }

    const statusFilter = req.query.status as any;
    const incidents = await observabilityService.listIncidents(statusFilter);

    res.json({
      success: true,
      data: incidents,
      requestId: req.id,
    });
  } catch (error) {
    next(error);
  }
}

export async function updateIncident(req: Request, res: Response, next: NextFunction) {
  try {
    const user = req.user;
    if (!user) throw new ForbiddenError('Authentication required');
    if (!isPlatformOwner(user)) {
      throw new ForbiddenError('Access restricted to Platform Operators');
    }

    const { id } = req.params;
    const { status } = req.body;
    if (!status || !['OPEN', 'ACKNOWLEDGED', 'RESOLVED'].includes(status)) {
      throw new BadRequestError('Valid status (OPEN, ACKNOWLEDGED, RESOLVED) is required');
    }

    const updated = await observabilityService.updateIncidentStatus(id, status, user.userId);
    if (!updated) {
      throw new BadRequestError(`Incident with ID ${id} not found`);
    }

    res.json({
      success: true,
      data: updated,
      requestId: req.id,
    });
  } catch (error) {
    next(error);
  }
}

export async function getSchedulerStatus(req: Request, res: Response, next: NextFunction) {
  try {
    const user = req.user;
    if (!user) throw new ForbiddenError('Authentication required');
    if (!isPlatformOwner(user)) {
      throw new ForbiddenError('Access restricted to Platform Operators');
    }

    const jobs = await observabilityService.getSchedulerStatuses();

    res.json({
      success: true,
      data: jobs,
      requestId: req.id,
    });
  } catch (error) {
    next(error);
  }
}

export async function getTenantHealth(req: Request, res: Response, next: NextFunction) {
  try {
    const user = req.user;
    if (!user) throw new ForbiddenError('Authentication required');

    const communityId = (req.query.communityId || req.params.communityId) as string;
    if (!communityId) throw new BadRequestError('communityId is required');

    const report = await observabilityService.getTenantHealthReport(communityId);

    res.json({
      success: true,
      data: report,
      requestId: req.id,
    });
  } catch (error) {
    next(error);
  }
}
