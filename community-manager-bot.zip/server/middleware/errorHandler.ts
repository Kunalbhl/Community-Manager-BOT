import { Request, Response, NextFunction } from 'express';
import { StandardError, getSafeUserMessageForCategory } from '../utils/standardError.js';
import { OperationalErrorCategory } from '../../shared/types/observability.js';
import { logger } from '../logging/logger.js';
import { observabilityService } from '../services/observability/observability.service.js';

export function standardErrorHandler(
  err: any,
  req: Request,
  res: Response,
  _next: NextFunction
) {
  const correlationId =
    err.correlationId || (req.headers['x-correlation-id'] as string) || `corr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const requestId = req.id || `req_${Date.now()}`;

  let statusCode = 500;
  let code: OperationalErrorCategory = 'INTERNAL_ERROR';
  let userMessage = 'An unexpected server error occurred.';
  let retryable = false;
  let requiredAction = err.requiredAction;

  if (err instanceof StandardError) {
    statusCode = err.statusCode;
    code = err.code;
    userMessage = err.userMessage;
    retryable = err.retryable;
  } else if (err.statusCode && typeof err.statusCode === 'number') {
    statusCode = err.statusCode;
    if (statusCode === 401) code = 'AUTHENTICATION_FAILED';
    else if (statusCode === 403) code = 'AUTHORIZATION_FAILED';
    else if (statusCode === 404) code = 'NOT_FOUND';
    else if (statusCode === 409) code = 'CONFLICT';
    else if (statusCode === 429) code = 'RATE_LIMITED';
    else if (statusCode === 400) code = 'VALIDATION_FAILED';
    userMessage = err.message || getSafeUserMessageForCategory(code);
  } else {
    userMessage = getSafeUserMessageForCategory('INTERNAL_ERROR');
  }

  const durationMs = (req as any).startTime ? Date.now() - (req as any).startTime : 0;

  // Record request metric
  observabilityService.recordRequest(durationMs, true);

  // Structured Operational Logging
  logger.logOperational({
    correlationId,
    requestId,
    communityId: (req.query?.communityId || req.params?.communityId || req.body?.communityId) as string,
    workspaceId: (req.query?.workspaceId || req.params?.workspaceId || req.body?.workspaceId) as string,
    operation: `${req.method} ${req.path}`,
    status: 'FAILURE',
    durationMs,
    errorCategory: code,
    errorMessage: err.message || userMessage,
  });

  // Record operational incident for 5xx errors or key dependency failures
  if (statusCode >= 500 || code === 'DISCORD_UNAVAILABLE' || code === 'DATABASE_UNAVAILABLE' || code === 'BILLING_FAILED') {
    observabilityService.recordIncident({
      category: code,
      dependency: code.includes('DISCORD') ? 'Discord' : code.includes('DATABASE') ? 'Database' : code.includes('BILLING') ? 'Billing' : 'Server',
      summary: `${req.method} ${req.path} failed: ${err.message || userMessage}`,
      correlationId,
      severity: statusCode >= 500 ? 'HIGH' : 'MEDIUM',
      recoveryInstructions: requiredAction,
    }).catch((e) => console.error('Failed to log incident:', e));
  }

  res.status(statusCode).json({
    success: false,
    error: {
      code,
      message: userMessage,
      correlationId,
      retryable,
      ...(requiredAction ? { requiredAction } : {}),
    },
    requestId,
  });
}

export const errorHandlerMiddleware = standardErrorHandler;
