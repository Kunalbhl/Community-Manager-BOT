import { config } from '../config/env.js';
import { logger } from '../logging/logger.js';
import { DiscordOAuthSession } from '../../shared/types/models.js';
import { FirestoreRepository } from '../repositories/firestore.repository.js';
import { IntegrationNotConfiguredError } from '../utils/errors.js';
import crypto from 'crypto';

export interface DiscordUserGuild {
  id: string;
  name: string;
  icon?: string;
  owner: boolean;
  permissions: string;
  features: string[];
}

export interface DiscordUserIdentity {
  id: string; // discordUserId
  username: string;
  discriminator: string;
  global_name?: string;
  avatar?: string;
  email?: string;
  verified?: boolean;
}

import { sessionsRepository } from '../repositories/index.js';

export class DiscordAuthService {
  private resolveCallbackUri(redirectUri?: string): string {
    if (redirectUri && !redirectUri.includes('discord.com') && redirectUri.startsWith('http')) {
      return redirectUri;
    }
    if (config.DISCORD_OAUTH_CALLBACK_URL && !config.DISCORD_OAUTH_CALLBACK_URL.includes('discord.com') && config.DISCORD_OAUTH_CALLBACK_URL.startsWith('http')) {
      return config.DISCORD_OAUTH_CALLBACK_URL;
    }
    if (config.APP_URL && !config.APP_URL.includes('discord.com') && config.APP_URL.startsWith('http')) {
      return `${config.APP_URL.replace(/\/+$/, '')}/api/v1/auth/callback`;
    }
    return 'http://localhost:3000/api/v1/auth/callback';
  }

  /**
   * Generates production Discord OAuth2 authorization URL requesting identify + guilds.
   * Supports PKCE code challenge.
   */
  getOAuthUrl(state: string, redirectUri?: string, codeChallenge?: string): string {
    const clientId = config.DISCORD_CLIENT_ID || config.DISCORD_APPLICATION_ID;
    if (!clientId) {
      throw new IntegrationNotConfiguredError('discord', 'DISCORD_CLIENT_ID is not configured. Set it to your Discord application Client ID.');
    }
    const rUri = this.resolveCallbackUri(redirectUri);
    const scopes = encodeURIComponent('identify guilds');
    const encState = encodeURIComponent(state);
    let url = `https://discord.com/oauth2/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(rUri)}&response_type=code&scope=${scopes}&state=${encState}`;
    if (codeChallenge) {
      url += `&code_challenge=${encodeURIComponent(codeChallenge)}&code_challenge_method=S256`;
    }
    return url;
  }

  /**
   * Generates Discord Bot installation URL with required granular permissions.
   */
  getBotInstallUrl(guildId?: string, redirectUri?: string): string {
    const clientId = config.DISCORD_CLIENT_ID || config.DISCORD_APPLICATION_ID;
    if (!clientId) {
      throw new IntegrationNotConfiguredError('discord', 'DISCORD_CLIENT_ID is not configured. Set it to your Discord application Client ID.');
    }
    // Granular permissions bitfield: View Channels (1024), Send Messages (2048), Embed Links (16384), Read Message History (65536), Use Slash Commands (2147483648), Manage Roles (268435456) = 2415982592
    const permissions = '2415982592';
    const scopes = encodeURIComponent('bot applications.commands');
    let url = `https://discord.com/oauth2/authorize?client_id=${clientId}&scope=${scopes}&permissions=${permissions}`;
    if (guildId) {
      url += `&guild_id=${guildId}&disable_guild_select=true`;
    }
    if (redirectUri && !redirectUri.includes('discord.com') && redirectUri.startsWith('http')) {
      url += `&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code`;
    }
    return url;
  }

  /**
   * Exchanges authorization code for OAuth tokens using Discord REST API with PKCE verification.
   */
  async exchangeCodeForToken(code: string, redirectUri?: string, codeVerifier?: string): Promise<{ accessToken: string; refreshToken?: string; expiresAt: number; scopes: string[] }> {
    const clientId = config.DISCORD_CLIENT_ID || config.DISCORD_APPLICATION_ID;
    const clientSecret = config.DISCORD_CLIENT_SECRET;
    const rUri = this.resolveCallbackUri(redirectUri);

    if (!clientId || !clientSecret) {
      throw new IntegrationNotConfiguredError('discord', 'Discord client credentials (secret) are unconfigured. Cannot perform live OAuth exchange.');
    }

    try {
      const params: Record<string, string> = {
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: 'authorization_code',
        code,
        redirect_uri: rUri,
      };

      if (codeVerifier) {
        params['code_verifier'] = codeVerifier;
      }

      const body = new URLSearchParams(params);

      const res = await fetch('https://discord.com/api/v10/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });

      if (!res.ok) {
        const errText = await res.text();
        logger.error(`[DiscordOAuth] Token exchange failed (${res.status}): ${errText}`);
        throw new Error(`Discord token exchange failed (${res.status}): ${errText}`);
      }

      const data = (await res.json()) as { access_token: string; refresh_token?: string; expires_in: number; scope: string };
      return {
        accessToken: data.access_token,
        refreshToken: data.refresh_token,
        expiresAt: Date.now() + data.expires_in * 1000,
        scopes: data.scope ? data.scope.split(' ') : ['identify', 'guilds'],
      };
    } catch (err) {
      logger.error(`[DiscordOAuth] Live OAuth exchange error: ${(err as Error).message}`);
      throw err;
    }
  }

  async exchangeCodeForTokens(code: string, redirectUri?: string, codeVerifier?: string): Promise<{ accessToken: string; refreshToken?: string; expiresAt: number; scopes: string[] }> {
    return this.exchangeCodeForToken(code, redirectUri, codeVerifier);
  }

  /**
   * Creates authoritative OAuth session stored in persistent sessions repository.
   */
  async createAuthoritativeSession(sessionData: any): Promise<any> {
    const sessionToken = sessionData.sessionToken || ('sess_' + crypto.randomBytes(32).toString('hex'));
    const docId = sessionData.id || sessionToken;
    const sessionRecord = {
      ...sessionData,
      id: docId,
      sessionToken,
    };
    await sessionsRepository.create(sessionRecord);
    return sessionRecord;
  }

  /**
   * Refreshes an expired OAuth access token using Discord REST API.
   */
  async refreshOAuthToken(refreshToken: string): Promise<{ accessToken: string; refreshToken?: string; expiresAt: number; scopes: string[] }> {
    const clientId = config.DISCORD_CLIENT_ID || config.DISCORD_APPLICATION_ID;
    const clientSecret = config.DISCORD_CLIENT_SECRET;

    if (!clientId || !clientSecret) {
      throw new IntegrationNotConfiguredError('discord', 'Discord client credentials (secret) are unconfigured. Cannot refresh token.');
    }

    try {
      const body = new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
      });

      const res = await fetch('https://discord.com/api/v10/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });

      if (!res.ok) {
        const errText = await res.text();
        logger.error(`[DiscordOAuth] Token refresh failed (${res.status}): ${errText}`);
        throw new Error('DISCORD_REAUTH_REQUIRED');
      }

      const data = (await res.json()) as { access_token: string; refresh_token?: string; expires_in: number; scope: string };
      return {
        accessToken: data.access_token,
        refreshToken: data.refresh_token || refreshToken,
        expiresAt: Date.now() + data.expires_in * 1000,
        scopes: data.scope ? data.scope.split(' ') : ['identify', 'guilds'],
      };
    } catch (err) {
      logger.error(`[DiscordOAuth] Token refresh error: ${(err as Error).message}`);
      throw err;
    }
  }

  /**
   * Revokes an OAuth token using Discord REST API.
   */
  async revokeOAuthToken(accessToken: string): Promise<boolean> {
    const clientId = config.DISCORD_CLIENT_ID || config.DISCORD_APPLICATION_ID;
    const clientSecret = config.DISCORD_CLIENT_SECRET;

    if (!clientId || !clientSecret) {
      return false;
    }

    try {
      const body = new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        token: accessToken,
        token_type_hint: 'access_token',
      });

      await fetch('https://discord.com/api/v10/oauth2/token/revoke', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });
      return true;
    } catch (err) {
      logger.warn(`[DiscordOAuth] Token revocation notice: ${(err as Error).message}`);
      return false;
    }
  }

  /**
   * Fetches Discord user profile from GET /users/@me
   */
  async getDiscordUser(accessTokenOrSessionToken: string): Promise<DiscordUserIdentity> {
    let accessToken = accessTokenOrSessionToken;
    if (accessTokenOrSessionToken.startsWith('sess_')) {
      const session = await this.getSessionByToken(accessTokenOrSessionToken);
      if (session && session.accessToken) {
        accessToken = session.accessToken;
      }
    }

    if (config.APP_RUNTIME_MODE === 'DEVELOPMENT_SIMULATION') {
      return {
        id: '1547515985416822884',
        username: 'interviewer_mock',
        discriminator: '0001',
        global_name: 'Mock Interviewer',
      };
    }

    const isMock = accessToken.startsWith('dev_token_') || accessToken.startsWith('mock_');
    if (isMock) {
      throw new Error('Invalid token scheme: Live authorization required. Simulated token rejected in production environments.');
    }

    const res = await fetch('https://discord.com/api/v10/users/@me', {
      headers: { Authorization: accessToken.startsWith('Bearer ') ? accessToken : `Bearer ${accessToken}` },
    });

    if (!res.ok) {
      throw new Error(`Failed to fetch Discord user identity: ${res.statusText}`);
    }

    return (await res.json()) as DiscordUserIdentity;
  }

  /**
   * Alias for getDiscordUser
   */
  async getUserFromToken(accessToken: string): Promise<DiscordUserIdentity> {
    return this.getDiscordUser(accessToken);
  }

  /**
   * Fetches Discord user guilds from GET /users/@me/guilds
   */
  async getDiscordUserGuilds(accessTokenOrSessionToken: string): Promise<DiscordUserGuild[]> {
    let accessToken = accessTokenOrSessionToken;
    if (accessTokenOrSessionToken.startsWith('sess_')) {
      const session = await this.getSessionByToken(accessTokenOrSessionToken);
      if (session && session.accessToken) {
        accessToken = session.accessToken;
      }
    }

    if (config.APP_RUNTIME_MODE === 'DEVELOPMENT_SIMULATION') {
      return [
        {
          id: '1547515985416822884',
          name: 'Development Community Guild',
          owner: true,
          permissions: '2415982592',
          features: [],
        },
      ];
    }

    const isMock = accessToken.startsWith('dev_token_') || accessToken.startsWith('mock_');
    if (isMock) {
      throw new Error('Invalid token scheme: Live authorization required. Simulated token rejected in production environments.');
    }

    const res = await fetch('https://discord.com/api/v10/users/@me/guilds', {
      headers: { Authorization: accessToken.startsWith('Bearer ') ? accessToken : `Bearer ${accessToken}` },
    });

    if (!res.ok) {
      throw new Error(`Failed to fetch user guilds from Discord: ${res.statusText}`);
    }

    return (await res.json()) as DiscordUserGuild[];
  }

  /**
   * Filter guilds where user has MANAGE_GUILD (0x20) or ADMINISTRATOR (0x8) or is owner
   */
  filterAdminGuilds(guilds: DiscordUserGuild[]): DiscordUserGuild[] {
    return guilds.filter((g) => {
      if (g.owner) return true;
      const perms = BigInt(g.permissions || '0');
      const ADMIN = BigInt(0x8);
      const MANAGE_GUILD = BigInt(0x20);
      return (perms & ADMIN) === ADMIN || (perms & MANAGE_GUILD) === MANAGE_GUILD;
    });
  }

  /**
   * Store active session and generate a secure custom session token
   */
  async saveSession(session: Omit<DiscordOAuthSession, 'id'> & { id?: string }): Promise<string> {
    const sessionToken = session.id || ('sess_' + crypto.randomBytes(32).toString('hex'));
    await sessionsRepository.create({
      ...session,
      sessionToken,
      id: sessionToken,
    } as any);
    return sessionToken;
  }

  /**
   * Retrieve active session by Discord User ID
   */
  async getSession(discordUserId: string): Promise<(DiscordOAuthSession & { sessionToken: string }) | undefined> {
    const results = await sessionsRepository.findByQuery({ discordUserId });
    return results.length > 0 ? results[0] : undefined;
  }

  /**
   * Retrieve active session by secure custom session token or raw token
   */
  async getSessionByToken(token: string): Promise<(DiscordOAuthSession & { sessionToken: string }) | undefined> {
    // 1. Try directly by sessionToken (which is the document ID)
    const session = await sessionsRepository.getById(token);
    if (session) return session;

    // 2. Query by sessionToken (fallback search)
    const resultsBySessionToken = await sessionsRepository.findByQuery({ sessionToken: token });
    if (resultsBySessionToken.length > 0) return resultsBySessionToken[0];

    return undefined;
  }
  /**
   * Update active session by sessionToken
   */
  async updateSession(sessionToken: string, updates: Partial<DiscordOAuthSession>): Promise<void> {
    await sessionsRepository.update(sessionToken, updates);
  }

  /**
   * Delete active session by sessionToken
   */
  async deleteSession(sessionToken: string): Promise<void> {
    await sessionsRepository.delete(sessionToken);
  }
}

export const discordAuthService = new DiscordAuthService();
