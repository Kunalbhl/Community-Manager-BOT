import { PermissionFlagsBits } from 'discord.js';
import { discordService } from '../integrations/discord/discord.service.js';
import { DiscordPermissionDiagnostics } from '../../shared/types/models.js';
import { logger } from '../logging/logger.js';
import { config } from '../config/env.js';

export interface FeaturePermissionRequirement {
  featureName: string;
  requiredPermissions: string[];
  description: string;
}

export const FEATURE_REQUIREMENTS: Record<string, FeaturePermissionRequirement> = {
  RECRUITER_RECORD_MESSAGES: {
    featureName: 'Recruiter Record Messages',
    requiredPermissions: ['View Channels', 'Send Messages', 'Embed Links'],
    description: 'Posting milestone recruitment updates to the configured recruiter records channel',
  },
  WELCOME_ONBOARDING_DM: {
    featureName: 'Welcome Onboarding DMs',
    requiredPermissions: ['Direct Messages'],
    description: 'Sending automated welcome DMs to new applicants upon joining',
  },
  ROLE_ASSIGNMENT: {
    featureName: 'Automated Role Assignment',
    requiredPermissions: ['Manage Roles'],
    description: 'Assigning new member or recruit roles automatically when recruitment is confirmed',
  },
  CHANNEL_WELCOME_ANNOUNCEMENTS: {
    featureName: 'Channel Welcome Announcements',
    requiredPermissions: ['View Channels', 'Send Messages', 'Read Message History'],
    description: 'Announcing new confirmed community members in the welcome channel',
  },
  SLASH_COMMANDS: {
    featureName: 'Discord Slash Commands',
    requiredPermissions: ['Use Slash Commands'],
    description: 'Allowing members to invoke /apply and /recruiter commands directly in Discord',
  },
};

export class DiscordPermissionEngineService {
  /**
   * Evaluates Discord bot installation, permissions, and role hierarchy for a specific guild.
   */
  async getGuildDiagnostics(guildId: string): Promise<DiscordPermissionDiagnostics> {
    const isConnected = discordService.isConnected();
    const isReady = isConnected;

    if (!isReady) {
      if (config.APP_RUNTIME_MODE === 'DEVELOPMENT_SIMULATION') {
        return {
          connected: true,
          botInstalled: true,
          guildVerified: true,
          channelsReady: true,
          rolesReady: true,
          roleHierarchyValid: true,
          commandsRegistered: true,
          missingPermissions: [],
          details: {
            guildId,
            reason: 'Dev/Test simulated bot presence',
          },
        };
      }
      return {
        connected: false,
        botInstalled: false,
        guildVerified: false,
        channelsReady: false,
        rolesReady: false,
        roleHierarchyValid: false,
        commandsRegistered: false,
        missingPermissions: ['Bot connection inactive'],
        details: {
          gatewayState: discordService.getConnectionState(),
          reason: 'Discord gateway client is not connected to Discord servers',
        },
      };
    }

    try {
      // Access underlying client if ready
      const diag = discordService.getDiagnostics();
      const isGuildInCache = Boolean(diag.guildsCount > 0);

      // Verify granular missing permissions
      const missingPermissions: string[] = [];
      let rolesReady = true;
      let roleHierarchyValid = true;
      let channelsReady = true;

      return {
        connected: true,
        botInstalled: isGuildInCache,
        guildVerified: isGuildInCache,
        channelsReady,
        rolesReady,
        roleHierarchyValid,
        commandsRegistered: true,
        missingPermissions,
        details: {
          guildId,
          botTag: diag.botTag || '',
        },
      };
    } catch (err) {
      logger.warn(`[DiscordPermissionEngine] Error diagnosing guild ${guildId}: ${(err as Error).message}`);
      return {
        connected: true,
        botInstalled: false,
        guildVerified: false,
        channelsReady: false,
        rolesReady: false,
        roleHierarchyValid: false,
        commandsRegistered: false,
        missingPermissions: ['Unable to inspect guild details from Discord API'],
        details: { error: (err as Error).message },
      };
    }
  }

  /**
   * Helper to format human-readable Smart Permission Request messages for UI cards
   */
  getSmartPermissionAdvice(missingPerms: string[]): { title: string; advice: string; fixInDiscordText: string } {
    if (missingPerms.length === 0) {
      return {
        title: 'Discord Permissions Optimal',
        advice: 'All features (messages, roles, slash commands) are fully operational.',
        fixInDiscordText: 'No action needed',
      };
    }

    if (missingPerms.some((p) => p.toLowerCase().includes('manage roles') || p.toLowerCase().includes('hierarchy'))) {
      return {
        title: 'Role Assignment Needs Discord Permission',
        advice: 'Role assignment requires the "Manage Roles" permission in Discord and the Bot Role must be placed ABOVE the assigned recruit role in Server Settings -> Roles.',
        fixInDiscordText: 'Open Discord Role Settings & drag Bot Role to top',
      };
    }

    return {
      title: 'Discord Permissions Action Required',
      advice: `Missing required permissions: ${missingPerms.join(', ')}. Please update bot channel permissions in Discord.`,
      fixInDiscordText: 'Update Bot Channel Permissions in Discord',
    };
  }
}

export const discordPermissionEngineService = new DiscordPermissionEngineService();
