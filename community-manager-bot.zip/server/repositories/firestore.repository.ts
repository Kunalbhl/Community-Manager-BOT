import { Firestore, WhereFilterOp } from '@google-cloud/firestore';
import fs from 'fs';
import path from 'path';
import { IRepository, QueryOptions } from './base.repository.js';
import { logger } from '../logging/logger.js';
import { config } from '../config/env.js';

let firestoreInstance: Firestore | null = null;
let firestoreInitialized = false;
let firestoreAvailable = false;

// Isolated development simulation store (only accessible in DEVELOPMENT_SIMULATION mode)
const simulationStores = new Map<string, Map<string, any>>();

export const isRealPersistenceMode = () =>
  config.APP_RUNTIME_MODE === 'PRODUCTION' || config.APP_RUNTIME_MODE === 'REAL_DISCORD_PREVIEW';

function getSimulationStore(collectionName: string): Map<string, any> {
  let store = simulationStores.get(collectionName);
  if (!store) {
    store = new Map();
    simulationStores.set(collectionName, store);
  }
  return store;
}

export function sanitizeFirestoreDatabaseId(dbId?: string | null): string | undefined {
  if (!dbId || typeof dbId !== 'string') return undefined;
  const trimmed = dbId.trim();
  if (
    trimmed.startsWith('http://') ||
    trimmed.startsWith('https://') ||
    trimmed.includes('/') ||
    trimmed.includes(':') ||
    trimmed.includes('firebasedatabase.app')
  ) {
    return undefined;
  }
  if (trimmed === '(default)') {
    return undefined;
  }
  return trimmed;
}

function handleFirestoreOpError(err: any, op: string, collection: string, id?: string) {
  const errMsg = err?.message || String(err);
  if (
    err?.code === 5 || // NOT_FOUND
    err?.code === 7 || // PERMISSION_DENIED
    err?.code === 14 || // UNAVAILABLE
    err?.code === 16 || // UNAUTHENTICATED
    err?.code === 3 || // INVALID_ARGUMENT
    errMsg.includes('NOT_FOUND') ||
    errMsg.includes('PERMISSION_DENIED') ||
    errMsg.includes('UNAUTHENTICATED') ||
    errMsg.includes('INVALID_ARGUMENT') ||
    errMsg.includes('UNAVAILABLE') ||
    errMsg.includes('Missing or insufficient permissions') ||
    errMsg.includes('Invalid database id') ||
    errMsg.includes('Could not load the default credentials')
  ) {
    if (firestoreAvailable) {
      firestoreAvailable = false;
      logger.info(
        `[FirestoreRepository] Remote Firestore connection inactive (${errMsg}). Switching seamlessly to memory store.`
      );
    }
  } else {
    logger.warn(`[FirestoreRepository] ${op} error on ${collection}${id ? `/${id}` : ''}: ${errMsg}. Using memory store.`);
  }
}

/**
 * Returns the initialized Firestore database instance or null if unavailable.
 */
export function getFirestoreDb(): Firestore | null {
  if (firestoreInitialized) {
    return firestoreAvailable ? firestoreInstance : null;
  }

  firestoreInitialized = true;

  try {
    // 1. Resolve Project ID
    let projectId =
      config.GOOGLE_CLOUD_PROJECT_ID ||
      process.env.GOOGLE_CLOUD_PROJECT_ID ||
      process.env.GCP_PROJECT ||
      process.env.GCLOUD_PROJECT;

    // 2. Resolve Database ID
    let databaseId = sanitizeFirestoreDatabaseId(config.FIRESTORE_DATABASE_ID) || sanitizeFirestoreDatabaseId(process.env.FIRESTORE_DATABASE_ID);

    if (!projectId) {
      logger.info('[FirestoreRepository] No GOOGLE_CLOUD_PROJECT_ID configured. Operating with high-performance local store.');
      firestoreAvailable = false;
      return null;
    }

    firestoreInstance = new Firestore({
      projectId,
      databaseId,
      ignoreUndefinedProperties: true,
    });

    firestoreAvailable = true;
    logger.info(
      `[FirestoreRepository] Initialized Firestore client for project: ${projectId}, database: ${databaseId || '(default)'}`
    );
    return firestoreInstance;
  } catch (err: any) {
    logger.info(
      `[FirestoreRepository] Could not initialize Firestore client (${err?.message || err}). Operating with local store.`
    );
    firestoreAvailable = false;
    return null;
  }
}

/**
 * Durable Firestore Repository Implementation.
 * Connects directly to Google Cloud Firestore with in-memory fallback.
 */
export class FirestoreRepository<T extends { id: string }> implements IRepository<T> {
  protected collectionName: string;

  constructor(collectionName: string) {
    this.collectionName = collectionName;
  }

  getCollectionName(): string {
    return this.collectionName;
  }

  async getById(id: string): Promise<T | null> {
    if (isRealPersistenceMode()) {
      const db = getFirestoreDb();
      if (!db) {
        throw new Error(`FIRESTORE_UNAVAILABLE: Real Firestore database is required for collection ${this.collectionName}`);
      }
      const docRef = db.collection(this.collectionName).doc(id);
      const docSnap = await docRef.get();
      if (docSnap.exists) {
        return { ...(docSnap.data() as any), id: docSnap.id } as T;
      }
      return null;
    }

    const db = getFirestoreDb();
    if (!db) {
      return getSimulationStore(this.collectionName).get(id) || null;
    }

    try {
      const docRef = db.collection(this.collectionName).doc(id);
      const docSnap = await docRef.get();
      if (docSnap.exists) {
        const data = { ...(docSnap.data() as any), id: docSnap.id } as T;
        getSimulationStore(this.collectionName).set(id, data);
        return data;
      }
      return null;
    } catch (err: any) {
      handleFirestoreOpError(err, 'getById', this.collectionName, id);
      return getSimulationStore(this.collectionName).get(id) || null;
    }
  }

  async findById(id: string): Promise<T | null> {
    return this.getById(id);
  }

  async findByQuery(query?: Record<string, any>): Promise<T[]> {
    const whereFilters: Array<{ field: string; operator: '==' | '!=' | '<' | '<=' | '>' | '>='; value: unknown }> = [];
    if (query) {
      for (const [k, v] of Object.entries(query)) {
        whereFilters.push({ field: k, operator: '==', value: v });
      }
    }
    return this.list({ where: whereFilters });
  }

  async findAll(): Promise<T[]> {
    return this.list();
  }

  async list(options?: QueryOptions): Promise<T[]> {
    if (isRealPersistenceMode()) {
      const db = getFirestoreDb();
      if (!db) {
        throw new Error(`FIRESTORE_UNAVAILABLE: Real Firestore database is required for collection ${this.collectionName}`);
      }
      let q: any = db.collection(this.collectionName);

      if (options?.where && options.where.length > 0) {
        for (const filter of options.where) {
          q = q.where(filter.field, filter.operator as WhereFilterOp, filter.value);
        }
      }

      if (options?.orderBy) {
        q = q.orderBy(options.orderBy, options.orderDirection || 'asc');
      }

      if (typeof options?.offset === 'number') {
        q = q.offset(options.offset);
      }

      if (typeof options?.limit === 'number') {
        q = q.limit(options.limit);
      }

      const querySnapshot = await q.get();
      const results: T[] = [];
      querySnapshot.forEach((doc: any) => {
        results.push({ ...(doc.data() as any), id: doc.id } as T);
      });
      return results;
    }

    const db = getFirestoreDb();
    if (!db) {
      return this.listFromMemory(options);
    }

    try {
      let q: any = db.collection(this.collectionName);

      if (options?.where && options.where.length > 0) {
        for (const filter of options.where) {
          q = q.where(filter.field, filter.operator as WhereFilterOp, filter.value);
        }
      }

      if (options?.orderBy) {
        q = q.orderBy(options.orderBy, options.orderDirection || 'asc');
      }

      if (typeof options?.offset === 'number') {
        q = q.offset(options.offset);
      }

      if (typeof options?.limit === 'number') {
        q = q.limit(options.limit);
      }

      const querySnapshot = await q.get();
      const results: T[] = [];
      querySnapshot.forEach((doc: any) => {
        results.push({ ...(doc.data() as any), id: doc.id } as T);
      });

      const memStore = getSimulationStore(this.collectionName);
      for (const item of results) {
        memStore.set(item.id, item);
      }

      return results;
    } catch (err: any) {
      handleFirestoreOpError(err, 'list', this.collectionName);
      return this.listFromMemory(options);
    }
  }

  async listForTenant(tenantId: string, options?: QueryOptions): Promise<T[]> {
    const tenantFilter = {
      field: 'communityId',
      operator: '==' as const,
      value: tenantId,
    };

    const combinedOptions: QueryOptions = {
      ...options,
      where: [...(options?.where || []), tenantFilter],
    };

    return this.list(combinedOptions);
  }

  async create(itemOrId: string | (Omit<T, 'id'> & { id?: string }), maybeItem?: any): Promise<T> {
    let id: string;
    let data: any;

    if (typeof itemOrId === 'string') {
      id = itemOrId;
      data = { ...(maybeItem || {}), id };
    } else {
      id = itemOrId.id || `doc_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      data = { ...itemOrId, id };
    }

    if (isRealPersistenceMode()) {
      const db = getFirestoreDb();
      if (!db) {
        throw new Error(`FIRESTORE_UNAVAILABLE: Real Firestore database is required for collection ${this.collectionName}`);
      }
      const docRef = db.collection(this.collectionName).doc(id);
      await docRef.set(data);
      return data as T;
    }

    const memStore = getSimulationStore(this.collectionName);
    memStore.set(id, data);

    const db = getFirestoreDb();
    if (!db) {
      return data as T;
    }

    try {
      const docRef = db.collection(this.collectionName).doc(id);
      await docRef.set(data);
      return data as T;
    } catch (err: any) {
      handleFirestoreOpError(err, 'create', this.collectionName, id);
      return data as T;
    }
  }

  async update(id: string, updates: Partial<T>): Promise<T> {
    if (isRealPersistenceMode()) {
      const db = getFirestoreDb();
      if (!db) {
        throw new Error(`FIRESTORE_UNAVAILABLE: Real Firestore database is required for collection ${this.collectionName}`);
      }
      const docRef = db.collection(this.collectionName).doc(id);
      await docRef.set(updates as any, { merge: true });
      const snap = await docRef.get();
      if (snap.exists) {
        return { ...(snap.data() as any), id: snap.id } as T;
      }
      return { ...(updates as any), id } as T;
    }

    const memStore = getSimulationStore(this.collectionName);
    const existing = memStore.get(id) || { id };
    const updated = { ...existing, ...updates, id };
    memStore.set(id, updated);

    const db = getFirestoreDb();
    if (!db) {
      return updated;
    }

    try {
      const docRef = db.collection(this.collectionName).doc(id);
      await docRef.set(updates as any, { merge: true });
      const snap = await docRef.get();
      if (snap.exists) {
        const fresh = { ...(snap.data() as any), id: snap.id } as T;
        memStore.set(id, fresh);
        return fresh;
      }
      return updated;
    } catch (err: any) {
      handleFirestoreOpError(err, 'update', this.collectionName, id);
      return updated;
    }
  }

  async upsert(idOrItem: string | (Partial<T> & { id: string }), maybeItem?: Partial<T>): Promise<T> {
    const id = typeof idOrItem === 'string' ? idOrItem : idOrItem.id;
    const item = typeof idOrItem === 'string' ? (maybeItem || {}) : idOrItem;
    const data = { ...item, id };

    if (isRealPersistenceMode()) {
      const db = getFirestoreDb();
      if (!db) {
        throw new Error(`FIRESTORE_UNAVAILABLE: Real Firestore database is required for collection ${this.collectionName}`);
      }
      const docRef = db.collection(this.collectionName).doc(id);
      await docRef.set(data, { merge: true });
      const snap = await docRef.get();
      if (snap.exists) {
        return { ...(snap.data() as any), id: snap.id } as T;
      }
      return data as T;
    }

    const memStore = getSimulationStore(this.collectionName);
    const existing = memStore.get(id) || {};
    const merged = { ...existing, ...data };
    memStore.set(id, merged);

    const db = getFirestoreDb();
    if (!db) {
      return merged;
    }

    try {
      const docRef = db.collection(this.collectionName).doc(id);
      await docRef.set(data, { merge: true });
      const snap = await docRef.get();
      if (snap.exists) {
        const fresh = { ...(snap.data() as any), id: snap.id } as T;
        memStore.set(id, fresh);
        return fresh;
      }
      return merged;
    } catch (err: any) {
      handleFirestoreOpError(err, 'upsert', this.collectionName, id);
      return merged;
    }
  }

  async delete(id: string): Promise<boolean> {
    if (isRealPersistenceMode()) {
      const db = getFirestoreDb();
      if (!db) {
        throw new Error(`FIRESTORE_UNAVAILABLE: Real Firestore database is required for collection ${this.collectionName}`);
      }
      const docRef = db.collection(this.collectionName).doc(id);
      await docRef.delete();
      return true;
    }

    const memStore = getSimulationStore(this.collectionName);
    memStore.delete(id);

    const db = getFirestoreDb();
    if (!db) {
      return true;
    }

    try {
      const docRef = db.collection(this.collectionName).doc(id);
      await docRef.delete();
      return true;
    } catch (err: any) {
      handleFirestoreOpError(err, 'delete', this.collectionName, id);
      return true;
    }
  }

  async count(options?: QueryOptions): Promise<number> {
    if (isRealPersistenceMode()) {
      const db = getFirestoreDb();
      if (!db) {
        throw new Error(`FIRESTORE_UNAVAILABLE: Real Firestore database is required for collection ${this.collectionName}`);
      }
      let q: any = db.collection(this.collectionName);
      if (options?.where && options.where.length > 0) {
        for (const filter of options.where) {
          q = q.where(filter.field, filter.operator as WhereFilterOp, filter.value);
        }
      }
      const snapshot = await q.count().get();
      return snapshot.data().count;
    }

    const db = getFirestoreDb();
    if (!db) {
      if (!options?.where || options.where.length === 0) {
        return getSimulationStore(this.collectionName).size;
      }
      const list = this.listFromMemory(options);
      return list.length;
    }

    try {
      let q: any = db.collection(this.collectionName);
      if (options?.where && options.where.length > 0) {
        for (const filter of options.where) {
          q = q.where(filter.field, filter.operator as WhereFilterOp, filter.value);
        }
      }
      const snapshot = await q.count().get();
      return snapshot.data().count;
    } catch (err: any) {
      handleFirestoreOpError(err, 'count', this.collectionName);
      const list = this.listFromMemory(options);
      return list.length;
    }
  }

  async countForTenant(communityId: string, options?: QueryOptions): Promise<number> {
    const tenantFilter = {
      field: 'communityId',
      operator: '==' as const,
      value: communityId,
    };

    const combinedOptions: QueryOptions = {
      ...options,
      where: [...(options?.where || []), tenantFilter],
    };

    return this.count(combinedOptions);
  }

  private listFromMemory(options?: QueryOptions): T[] {
    if (isRealPersistenceMode()) {
      throw new Error('FAIL_CLOSED: In-memory simulation persistence is strictly prohibited in PRODUCTION and REAL_DISCORD_PREVIEW modes. Real Firestore connection is required.');
    }
    const store = getSimulationStore(this.collectionName);
    let items = Array.from(store.values());

    if (options?.where && options.where.length > 0) {
      for (const filter of options.where) {
        items = items.filter((item) => {
          const val = item[filter.field];
          if (filter.operator === '==') return val === filter.value;
          if (filter.operator === '!=') return val !== filter.value;
          if (filter.operator === '>') return val > filter.value;
          if (filter.operator === '>=') return val >= filter.value;
          if (filter.operator === '<') return val < filter.value;
          if (filter.operator === '<=') return val <= filter.value;
          if (filter.operator === 'array-contains') {
            return Array.isArray(val) && val.includes(filter.value);
          }
          if (filter.operator === 'in') {
            return Array.isArray(filter.value) && filter.value.includes(val);
          }
          return true;
        });
      }
    }

    if (options?.orderBy) {
      const field = options.orderBy;
      const dir = options.orderDirection === 'desc' ? -1 : 1;
      items.sort((a, b) => {
        if (a[field] < b[field]) return -1 * dir;
        if (a[field] > b[field]) return 1 * dir;
        return 0;
      });
    }

    if (typeof options?.offset === 'number' || typeof options?.limit === 'number') {
      const offset = options?.offset || 0;
      const limit = options?.limit !== undefined ? options.limit : items.length;
      items = items.slice(offset, offset + limit);
    }

    return items;
  }
}

/**
 * Explicitly isolated Development Simulation Persistence Provider.
 * Prohibited from instantiation in PRODUCTION or REAL_DISCORD_PREVIEW modes.
 */
export class DevelopmentSimulationPersistenceProvider<T extends { id: string }> implements IRepository<T> {
  protected collectionName: string;

  constructor(collectionName: string) {
    if (isRealPersistenceMode()) {
      throw new Error('FAIL_CLOSED: Simulation persistence is strictly prohibited in PRODUCTION or REAL_DISCORD_PREVIEW modes.');
    }
    this.collectionName = collectionName;
  }

  getCollectionName(): string {
    return this.collectionName;
  }

  async getById(id: string): Promise<T | null> {
    const store = getSimulationStore(this.collectionName);
    return store.get(id) || null;
  }

  async getByIdForTenant(communityId: string, id: string): Promise<T | null> {
    const doc = await this.getById(id);
    if (!doc) return null;
    return (doc as any).communityId === communityId ? doc : null;
  }

  async create(data: Omit<T, 'id'> & { id?: string }): Promise<T> {
    const store = getSimulationStore(this.collectionName);
    const id = data.id || `sim_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const now = new Date();
    const item = { ...data, id, createdAt: (data as any).createdAt || now, updatedAt: now } as unknown as T;
    store.set(id, item);
    return item;
  }

  async update(id: string, updates: Partial<T>): Promise<T> {
    const store = getSimulationStore(this.collectionName);
    const existing = store.get(id);
    if (!existing) {
      throw new Error(`Document with id ${id} not found in collection ${this.collectionName}`);
    }
    const updated = { ...existing, ...updates, updatedAt: new Date() } as unknown as T;
    store.set(id, updated);
    return updated;
  }

  async upsert(idOrItem: string | (Partial<T> & { id: string }), maybeItem?: Partial<T>): Promise<T> {
    const store = getSimulationStore(this.collectionName);
    let id: string;
    let updates: Partial<T>;

    if (typeof idOrItem === 'string') {
      id = idOrItem;
      updates = maybeItem || {};
    } else {
      id = idOrItem.id;
      updates = idOrItem;
    }

    const existing = store.get(id);
    const now = new Date();
    if (existing) {
      const merged = { ...existing, ...updates, updatedAt: now } as unknown as T;
      store.set(id, merged);
      return merged;
    } else {
      const item = { ...updates, id, createdAt: (updates as any).createdAt || now, updatedAt: now } as unknown as T;
      store.set(id, item);
      return item;
    }
  }

  async delete(id: string): Promise<boolean> {
    const store = getSimulationStore(this.collectionName);
    return store.delete(id);
  }

  async list(options?: QueryOptions): Promise<T[]> {
    const store = getSimulationStore(this.collectionName);
    let items = Array.from(store.values());

    if (options?.where && options.where.length > 0) {
      for (const filter of options.where) {
        items = items.filter((item) => {
          const val = item[filter.field];
          if (filter.operator === '==') return val === filter.value;
          if (filter.operator === '!=') return val !== filter.value;
          if (filter.operator === '>') return val > filter.value;
          if (filter.operator === '>=') return val >= filter.value;
          if (filter.operator === '<') return val < filter.value;
          if (filter.operator === '<=') return val <= filter.value;
          if (filter.operator === 'array-contains') {
            return Array.isArray(val) && val.includes(filter.value);
          }
          if (filter.operator === 'in') {
            return Array.isArray(filter.value) && filter.value.includes(val);
          }
          return true;
        });
      }
    }

    if (options?.orderBy) {
      const field = options.orderBy;
      const dir = options.orderDirection === 'desc' ? -1 : 1;
      items.sort((a, b) => {
        if (a[field] < b[field]) return -1 * dir;
        if (a[field] > b[field]) return 1 * dir;
        return 0;
      });
    }

    if (typeof options?.offset === 'number' || typeof options?.limit === 'number') {
      const offset = options?.offset || 0;
      const limit = options?.limit !== undefined ? options.limit : items.length;
      items = items.slice(offset, offset + limit);
    }

    return items;
  }

  async listForTenant(communityId: string, options?: QueryOptions): Promise<T[]> {
    const tenantFilter = {
      field: 'communityId',
      operator: '==' as const,
      value: communityId,
    };
    const combinedOptions: QueryOptions = {
      ...options,
      where: [...(options?.where || []), tenantFilter],
    };
    return this.list(combinedOptions);
  }

  async findByQuery(query: Partial<T>): Promise<T[]> {
    const store = getSimulationStore(this.collectionName);
    return Array.from(store.values()).filter((item) => {
      return Object.entries(query).every(([key, val]) => item[key] === val);
    });
  }

  async findByQueryForTenant(communityId: string, query: Partial<T>): Promise<T[]> {
    return this.findByQuery({ ...query, communityId } as any);
  }

  async count(options?: QueryOptions): Promise<number> {
    const items = await this.list(options);
    return items.length;
  }

  async countForTenant(communityId: string, options?: QueryOptions): Promise<number> {
    const items = await this.listForTenant(communityId, options);
    return items.length;
  }
}

