import React, { useEffect, useState } from 'react';
import {
  Activity,
  Server,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Clock,
  Radio,
  Zap,
  ShieldCheck,
  FileText,
  Cpu,
  Database,
  CreditCard,
  List,
} from 'lucide-react';
import {
  SystemHealthOverview,
  IncidentDocument,
  ScheduledJobStatus,
  DependencyHealthReport,
} from '../../../types';

export const ProductionOperationsView: React.FC = () => {
  const [health, setHealth] = useState<SystemHealthOverview | null>(null);
  const [incidents, setIncidents] = useState<IncidentDocument[]>([]);
  const [schedulerJobs, setSchedulerJobs] = useState<ScheduledJobStatus[]>([]);
  const [discordDiagnostic, setDiscordDiagnostic] = useState<any>(null);
  const [productionReadiness, setProductionReadiness] = useState<any>(null);
  const [developerPortalAudit, setDeveloperPortalAudit] = useState<any>(null);
  const [incidentFilter, setIncidentFilter] = useState<'ALL' | 'OPEN' | 'ACKNOWLEDGED' | 'RESOLVED'>('OPEN');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [targetStatus, setTargetStatus] = useState<string>('APP_DIRECTORY_SUBMITTED');
  const [confirmManualSubmission, setConfirmManualSubmission] = useState(false);
  const [statusNotes, setStatusNotes] = useState('');
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [statusSuccessMsg, setStatusSuccessMsg] = useState('');

  const fetchOpsData = async () => {
    setRefreshing(true);
    try {
      const [hRes, iRes, sRes, prRes, auditRes] = await Promise.all([
        fetch('/api/v1/ops/health'),
        fetch('/api/v1/ops/incidents'),
        fetch('/api/v1/ops/scheduler'),
        fetch('/api/v1/production-readiness'),
        fetch('/api/v1/discord/developer-portal-audit'),
      ]);

      if (hRes.ok) {
        const hJson = await hRes.json();
        if (hJson.success) {
          setHealth(hJson.data.health);
          setDiscordDiagnostic(hJson.data.discordDiagnostic);
        }
      }
      if (iRes.ok) {
        const iJson = await iRes.json();
        if (iJson.success) {
          setIncidents(iJson.data);
        }
      }
      if (sRes.ok) {
        const sJson = await sRes.json();
        if (sJson.success) {
          setSchedulerJobs(sJson.data);
        }
      }
      if (prRes.ok) {
        const prJson = await prRes.json();
        if (prJson.success) {
          setProductionReadiness(prJson.data);
        }
      }
      if (auditRes.ok) {
        const auditJson = await auditRes.json();
        if (auditJson.success) {
          setDeveloperPortalAudit(auditJson.data);
        }
      }
    } catch (err) {
      console.error('Failed to load operations data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleUpdateAppDirectoryStatus = async () => {
    setUpdatingStatus(true);
    setStatusSuccessMsg('');
    try {
      const res = await fetch('/api/v1/discord/app-directory-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: targetStatus,
          confirmed: confirmManualSubmission,
          notes: statusNotes,
          confirmationSource: 'Admin Release Launch Control',
        }),
      });
      const data = await res.json();
      if (data.success) {
        setStatusSuccessMsg(`App Directory status updated to ${targetStatus}`);
        fetchOpsData();
      } else {
        alert(data.error?.message || 'Failed to update status');
      }
    } catch (err) {
      console.error('Error updating App Directory status:', err);
    } finally {
      setUpdatingStatus(false);
    }
  };

  useEffect(() => {
    fetchOpsData();
    const timer = setInterval(fetchOpsData, 15000); // Poll every 15s
    return () => clearInterval(timer);
  }, []);

  const handleUpdateIncidentStatus = async (id: string, status: 'ACKNOWLEDGED' | 'RESOLVED') => {
    try {
      const res = await fetch(`/api/v1/ops/incidents/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        fetchOpsData();
      }
    } catch (err) {
      console.error('Failed to update incident:', err);
    }
  };

  if (loading) {
    return (
      <div className="p-8 text-center text-zinc-400 space-y-3">
        <RefreshCw className="w-8 h-8 animate-spin mx-auto text-indigo-500" />
        <p className="text-sm">Initializing Production Operations Observatory...</p>
      </div>
    );
  }

  const filteredIncidents = incidents.filter((i) => {
    if (incidentFilter === 'ALL') return true;
    return i.status === incidentFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-zinc-900/80 p-5 rounded-2xl border border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold text-white">Production Operations Observatory</h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Real-time telemetry, dependency health, scheduler status, and incident recovery manager.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={fetchOpsData}
            disabled={refreshing}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium rounded-lg border border-zinc-700 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh Diagnostics
          </button>
        </div>
      </div>

      {/* Overview Metrics Cards */}
      {productionReadiness && (
        <div className="bg-zinc-900/80 border border-indigo-500/30 rounded-2xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">Administrator Production Readiness Dashboard</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-950 text-indigo-300 border border-indigo-800">
                  {productionReadiness.environment}
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Authoritative runtime environment & single-bot gateway verification.
              </p>
            </div>
            <div className="text-right text-[11px] text-zinc-400">
              <span className="block font-mono text-zinc-300">{productionReadiness.appUrl}</span>
              <span className="text-zinc-500">OAuth Callback: {productionReadiness.oauthCallbackUrl}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 text-xs">
            {Object.entries(productionReadiness.statuses || {}).map(([key, status]: [string, any]) => (
              <div key={key} className="bg-zinc-950/70 p-2.5 rounded-xl border border-zinc-800/80 flex items-center justify-between">
                <span className="text-zinc-300 font-medium">{key}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    status === 'READY' || status === 'DIRECT_INSTALL_READY'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                      : status === 'OPTIONAL'
                      ? 'bg-blue-950 text-blue-300 border border-blue-800/60'
                      : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                  }`}
                >
                  {status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Discord App Directory Submission & Launch Control Panel */}
      {developerPortalAudit && (
        <div className="bg-zinc-900/90 border border-amber-500/30 rounded-2xl p-5 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">Discord App Directory Submission & Launch Control</h3>
                <span
                  className={`px-2.5 py-0.5 rounded text-[10px] font-bold border uppercase tracking-wider ${
                    developerPortalAudit.submissionControl?.currentStatus === 'APP_DIRECTORY_PUBLISHED'
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                      : developerPortalAudit.submissionControl?.currentStatus === 'APP_DIRECTORY_SUBMITTED' ||
                        developerPortalAudit.submissionControl?.currentStatus === 'APP_DIRECTORY_REVIEW'
                      ? 'bg-sky-950 text-sky-300 border-sky-800'
                      : 'bg-amber-950 text-amber-300 border-amber-800'
                  }`}
                >
                  {developerPortalAudit.submissionControl?.currentStatus}
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-1">
                Authoritative launch control for external Discord App Directory publication and direct bot installation.
              </p>
            </div>
          </div>

          {/* Alert / Notice for Manual Owner Submission */}
          {developerPortalAudit.submissionControl?.currentStatus === 'APP_DIRECTORY_SUBMISSION_READY' && (
            <div className="bg-amber-950/40 border border-amber-800/60 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1 text-xs">
                <h4 className="font-bold text-amber-200">ACTION REQUIRED: Owner Manual Submission</h4>
                <p className="text-zinc-300 leading-relaxed">
                  All 16 internal technical, legal, and visual requirements are <strong>100% SUBMISSION_READY</strong>.
                  Direct Discord bot installation is fully active and functioning.
                  To complete external publication in Discord's App Directory, open the <strong>Discord Developer Portal</strong> for your existing Community Manager application and click <em>Submit for Review</em>.
                </p>
              </div>
            </div>
          )}

          {/* 16 Item Readiness Checklist Grid */}
          <div>
            <h4 className="text-xs font-bold text-zinc-300 mb-2.5 flex items-center justify-between">
              <span>App Directory 16-Item Verification Checklist</span>
              <span className="text-[10px] text-emerald-400 font-mono">16 / 16 READY</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
              {(developerPortalAudit.checklist || []).map((item: any) => (
                <div key={item.id} className="bg-zinc-950/70 p-3 rounded-xl border border-zinc-800/80 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">{item.category}</span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800/60">
                      {item.status}
                    </span>
                  </div>
                  <div className="font-medium text-white truncate">{item.name}</div>
                  <div className="text-[11px] text-zinc-400 font-mono truncate">{item.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Admin Status Transition Control Form */}
          <div className="bg-zinc-950/80 border border-zinc-800 rounded-xl p-4 space-y-3 text-xs">
            <h4 className="font-bold text-zinc-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-400" /> Update App Directory Lifecycle State
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-zinc-400 mb-1">Target Status</label>
                <select
                  value={targetStatus}
                  onChange={(e) => setTargetStatus(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-zinc-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="APP_DIRECTORY_SUBMISSION_READY">APP_DIRECTORY_SUBMISSION_READY</option>
                  <option value="APP_DIRECTORY_SUBMITTED">APP_DIRECTORY_SUBMITTED</option>
                  <option value="APP_DIRECTORY_REVIEW">APP_DIRECTORY_REVIEW</option>
                  <option value="APP_DIRECTORY_PUBLISHED">APP_DIRECTORY_PUBLISHED</option>
                  <option value="APP_DIRECTORY_REJECTED">APP_DIRECTORY_REJECTED</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-[11px] font-medium text-zinc-400 mb-1">State Audit Notes (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g., Submitted via Discord Developer Portal dashboard by owner."
                  value={statusNotes}
                  onChange={(e) => setStatusNotes(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-zinc-800/80">
              <label className="flex items-center gap-2 cursor-pointer text-zinc-300 font-medium">
                <input
                  type="checkbox"
                  checked={confirmManualSubmission}
                  onChange={(e) => setConfirmManualSubmission(e.target.checked)}
                  className="rounded bg-zinc-900 border-zinc-700 text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                />
                <span>I confirm that this action was manually completed/verified in the Discord Developer Portal.</span>
              </label>

              <button
                onClick={handleUpdateAppDirectoryStatus}
                disabled={updatingStatus || (['APP_DIRECTORY_SUBMITTED', 'APP_DIRECTORY_PUBLISHED'].includes(targetStatus) && !confirmManualSubmission)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-lg transition-colors shrink-0"
              >
                {updatingStatus ? 'Saving...' : 'Update Status'}
              </button>
            </div>

            {statusSuccessMsg && (
              <p className="text-emerald-400 font-medium text-[11px] mt-2">{statusSuccessMsg}</p>
            )}
          </div>
        </div>
      )}

      {health && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-800">
            <span className="text-xs text-zinc-400">System Status</span>
            <div className="flex items-center gap-2 mt-2">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  health.status === 'HEALTHY'
                    ? 'bg-emerald-500'
                    : health.status === 'DEGRADED'
                    ? 'bg-amber-500'
                    : 'bg-red-500'
                }`}
              />
              <span className="text-sm font-bold text-zinc-100">{health.status}</span>
            </div>
            <span className="text-[10px] text-zinc-500 mt-1 block">Uptime: {health.uptimeSeconds}s</span>
          </div>

          <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-800">
            <span className="text-xs text-zinc-400">Total Requests</span>
            <p className="text-lg font-bold text-zinc-100 mt-1">{health.metrics.totalRequests}</p>
            <span className="text-[10px] text-zinc-500">Recorded telemetry hits</span>
          </div>

          <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-800">
            <span className="text-xs text-zinc-400">Error Rate</span>
            <p className={`text-lg font-bold mt-1 ${health.metrics.errorRatePercent > 5 ? 'text-red-400' : 'text-emerald-400'}`}>
              {health.metrics.errorRatePercent}%
            </p>
            <span className="text-[10px] text-zinc-500">{health.metrics.totalErrors} failed requests</span>
          </div>

          <div className="bg-zinc-900/60 p-4 rounded-xl border border-zinc-800">
            <span className="text-xs text-zinc-400">Avg Latency</span>
            <p className="text-lg font-bold text-zinc-100 mt-1">{health.metrics.avgLatencyMs}ms</p>
            <span className="text-[10px] text-zinc-500">Average response time</span>
          </div>
        </div>
      )}

      {/* Dependency Health Cards */}
      <div>
        <h3 className="text-sm font-bold text-zinc-200 mb-3 flex items-center gap-2">
          <Server className="w-4 h-4 text-indigo-400" />
          Dependency Health & Isolation Status
        </h3>
        {health?.dependencies && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {Object.entries(health.dependencies).map(([key, dep]: [string, DependencyHealthReport]) => (
              <div key={key} className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-4 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-zinc-200">{dep.name}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      dep.status === 'HEALTHY'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/50'
                        : dep.status === 'DEGRADED'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800/50'
                        : dep.status === 'UNAVAILABLE'
                        ? 'bg-red-950 text-red-300 border border-red-800/50'
                        : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                    }`}
                  >
                    {dep.status}
                  </span>
                </div>
                {dep.details && <p className="text-zinc-400 text-[11px] leading-relaxed">{dep.details}</p>}
                {dep.recoveryAction && (
                  <div className="bg-zinc-950/60 p-2 rounded border border-zinc-800/60 text-[10px] text-indigo-300">
                    <strong>Recovery: </strong>
                    {dep.recoveryAction}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Scheduler Monitoring Panel */}
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-bold text-zinc-200">Scheduled Jobs & Background Workers</h3>
          </div>
          <span className="text-xs text-zinc-400">{schedulerJobs.length} active job drivers</span>
        </div>

        {schedulerJobs.length === 0 ? (
          <p className="text-xs text-zinc-500 py-4 text-center">No scheduled job executions recorded yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-zinc-300">
              <thead className="bg-zinc-950/40 text-zinc-400 uppercase text-[10px] tracking-wider border-b border-zinc-800">
                <tr>
                  <th className="py-2.5 px-3">Job Name</th>
                  <th className="py-2.5 px-3">Module</th>
                  <th className="py-2.5 px-3">Last Status</th>
                  <th className="py-2.5 px-3">Last Execution</th>
                  <th className="py-2.5 px-3">Execs / Failures</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {schedulerJobs.map((job) => (
                  <tr key={job.id} className="hover:bg-zinc-800/30">
                    <td className="py-2.5 px-3 font-medium text-zinc-200">{job.jobName}</td>
                    <td className="py-2.5 px-3 text-zinc-400">{job.module}</td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          job.lastStatus === 'SUCCESS'
                            ? 'bg-emerald-950 text-emerald-400'
                            : job.lastStatus === 'FAILURE'
                            ? 'bg-red-950 text-red-400'
                            : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {job.lastStatus}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-zinc-400">
                      {job.lastExecutionAt ? new Date(job.lastExecutionAt).toLocaleTimeString() : 'Never'}
                    </td>
                    <td className="py-2.5 px-3">
                      {job.executionCount} total / <span className="text-red-400">{job.failureCount} failed</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Incident Management Panel */}
      <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-zinc-200">Incident & Safety Event Records</h3>
          </div>
          <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800 text-xs">
            {(['ALL', 'OPEN', 'ACKNOWLEDGED', 'RESOLVED'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setIncidentFilter(filter)}
                className={`px-2.5 py-1 rounded-md transition-colors font-medium text-[11px] ${
                  incidentFilter === filter ? 'bg-indigo-600 text-white' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        {filteredIncidents.length === 0 ? (
          <div className="p-8 text-center text-zinc-500 bg-zinc-950/20 rounded-xl border border-dashed border-zinc-800/80">
            <CheckCircle2 className="w-8 h-8 text-emerald-500/80 mx-auto mb-2" />
            <p className="text-xs font-medium text-zinc-300">No {incidentFilter.toLowerCase()} operational incidents found.</p>
            <p className="text-[11px] text-zinc-500 mt-1">System operating within normal parameters.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredIncidents.map((inc) => (
              <div
                key={inc.id}
                className="bg-zinc-950/60 border border-zinc-800 rounded-xl p-4 text-xs space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          inc.severity === 'CRITICAL'
                            ? 'bg-red-950 text-red-400 border border-red-800/60'
                            : inc.severity === 'HIGH'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800/60'
                            : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {inc.severity}
                      </span>
                      <span className="font-mono text-[10px] text-zinc-500">{inc.category}</span>
                      <span className="text-zinc-400">({inc.dependency})</span>
                    </div>
                    <h4 className="font-semibold text-zinc-200 text-sm mt-1.5">{inc.summary}</h4>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        inc.status === 'OPEN'
                          ? 'bg-red-950 text-red-300 border border-red-800/50'
                          : inc.status === 'ACKNOWLEDGED'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800/50'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-800/50'
                      }`}
                    >
                      {inc.status}
                    </span>
                  </div>
                </div>

                <div className="bg-zinc-900/80 p-2.5 rounded border border-zinc-800/80 text-[11px] text-indigo-200">
                  <strong className="font-medium text-indigo-300">Recovery Instructions: </strong>
                  {inc.recoveryInstructions}
                </div>

                <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1 border-t border-zinc-900">
                  <span>
                    Occurrences: <strong className="text-zinc-300">{inc.occurrenceCount}</strong> | First seen:{' '}
                    {new Date(inc.firstSeenAt).toLocaleTimeString()}
                  </span>
                  <div className="flex items-center gap-2">
                    {inc.status === 'OPEN' && (
                      <button
                        onClick={() => handleUpdateIncidentStatus(inc.id, 'ACKNOWLEDGED')}
                        className="px-2 py-1 bg-amber-950 hover:bg-amber-900 text-amber-300 rounded border border-amber-800/60 transition-colors"
                      >
                        Acknowledge
                      </button>
                    )}
                    {inc.status !== 'RESOLVED' && (
                      <button
                        onClick={() => handleUpdateIncidentStatus(inc.id, 'RESOLVED')}
                        className="px-2 py-1 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded border border-emerald-800/60 transition-colors"
                      >
                        Resolve Incident
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
