import React from 'react';
import {
  LayoutDashboard,
  Server,
  Users,
  BarChart3,
  MessageSquare,
  Activity,
  Settings,
  ShieldCheck,
  FileText,
  Sheet,
  Sparkles,
  X,
  ArrowLeft,
  User,
  Radio,
  Megaphone,
} from 'lucide-react';
import { PortalMode, PlatformSection, CommunitySection } from '../../types/ui.js';
import { UserRole, Permission } from '../../../shared/types/rbac.js';
import { hasPermission } from '../../../server/security/rbac.js';
import { BrandLogo } from '../brand/BrandLogo.js';

interface SidebarProps {
  portalMode: PortalMode;
  currentRole: UserRole;
  activePlatformSection: PlatformSection;
  onSelectPlatformSection: (section: PlatformSection) => void;
  activeCommunitySection: CommunitySection;
  onSelectCommunitySection: (section: CommunitySection) => void;
  onSelectPortalMode: (mode: PortalMode) => void;
  isOpen: boolean;
  onClose: () => void;
  onOpenPlatformAuth: () => void;
}

const PLATFORM_NAV_ITEMS: Array<{
  id: PlatformSection;
  label: string;
  icon: React.ElementType;
}> = [
  { id: 'overview', label: 'Platform Overview', icon: LayoutDashboard },
  { id: 'servers', label: 'Discord Servers', icon: Server },
  { id: 'users', label: 'Platform Users', icon: Users },
  { id: 'analytics', label: 'Platform Analytics', icon: BarChart3 },
  { id: 'feedback', label: 'Feedback & Ideas', icon: MessageSquare },
  { id: 'health', label: 'System Health', icon: Activity },
  { id: 'settings', label: 'Master Settings', icon: Settings },
  { id: 'audit', label: 'Security Audit Trail', icon: ShieldCheck },
];

interface PrimaryNavModule {
  id: CommunitySection;
  label: string;
  icon: React.ElementType;
  requiredPermission?: Permission;
  matchingSections: CommunitySection[];
}

const PRIMARY_COMMUNITY_NAV: PrimaryNavModule[] = [
  {
    id: 'home',
    label: 'HOME',
    icon: LayoutDashboard,
    matchingSections: ['home', 'dashboard', 'overview'],
  },
  {
    id: 'community',
    label: 'COMMUNITY',
    icon: Users,
    matchingSections: ['community', 'members', 'permissions', 'channels', 'welcome-onboarding', 'notifications', 'discord-ops', 'server-hygiene'],
  },
  {
    id: 'engagement',
    label: 'ENGAGEMENT',
    icon: Megaphone,
    matchingSections: ['engagement', 'announcements', 'campaigns', 'polls', 'templates'],
  },
  {
    id: 'recruitment',
    label: 'RECRUITMENT',
    icon: FileText,
    matchingSections: [
      'recruitment',
      'applications',
      'candidates',
      'interviews',
      'recruiters',
      'recruiter-codes',
      'recruiter-records',
      'referrals',
      'recruitment-trust',
      'campaign-workspace',
      'lifecycle-intelligence',
      'recruitment-command-center',
      'recruitment-settings',
      'onboarding-interview',
    ],
  },
  {
    id: 'moderation',
    label: 'MODERATION & SAFETY',
    icon: ShieldCheck,
    matchingSections: ['moderation', 'warnings', 'community-config', 'blacklist'],
  },
  {
    id: 'events-automation',
    label: 'EVENTS & AUTOMATION',
    icon: Radio,
    matchingSections: ['events-automation', 'events', 'automation'],
  },
  {
    id: 'insights-ai',
    label: 'INSIGHTS & AI',
    icon: Sparkles,
    matchingSections: ['insights-ai', 'insights-dashboard', 'ai', 'reports'],
  },
  {
    id: 'integrations',
    label: 'INTEGRATIONS',
    icon: Sheet,
    matchingSections: ['integrations', 'spreadsheet', 'google-calendar', 'discord-gateway'],
  },
  {
    id: 'settings',
    label: 'SETTINGS',
    icon: Settings,
    matchingSections: ['settings', 'pricing-trust'],
  },
];

export const Sidebar: React.FC<SidebarProps> = ({
  portalMode,
  currentRole,
  activePlatformSection,
  onSelectPlatformSection,
  activeCommunitySection,
  onSelectCommunitySection,
  onSelectPortalMode,
  isOpen,
  onClose,
  onOpenPlatformAuth,
}) => {
  const isPlatformMode = portalMode === 'PLATFORM_ADMIN';
  const authContext = { userId: 'current_user', role: currentRole };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-slate-200 bg-slate-900 text-slate-300 transition-transform duration-200 ease-in-out lg:static lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-0 max-lg:-translate-x-full'
        }`}
      >
        {/* Brand header */}
        <div className="flex h-16 items-center justify-between border-b border-slate-800 px-5">
          <BrandLogo
            variant="full"
            theme="dark"
            size="sm"
            subtitle={isPlatformMode ? 'Platform Owner Console' : 'Discord Native SaaS'}
          />
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation body */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
          {isPlatformMode ? (
            /* PLATFORM OWNER NAVIGATION */
            <div className="space-y-1">
              <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-amber-400 flex items-center justify-between">
                <span>Platform Modules</span>
                <span className="rounded bg-amber-400/20 px-1.5 py-0.2 text-[9px] text-amber-300">
                  Global
                </span>
              </div>

              {PLATFORM_NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activePlatformSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectPlatformSection(item.id);
                      onClose();
                    }}
                    className={`group flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium transition ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <Icon
                      className={`h-4 w-4 shrink-0 ${
                        isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}

              <div className="pt-4 px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Scope Switcher
              </div>

              <button
                onClick={() => {
                  onSelectPortalMode('COMMUNITY_DASHBOARD');
                  onClose();
                }}
                className="group flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition"
              >
                <ArrowLeft className="h-4 w-4 text-slate-400 group-hover:text-white" />
                <span>Return to Community View</span>
              </button>
            </div>
          ) : (
            /* 9 PRIMARY MODULES COMMUNITY MANAGER NAVIGATION */
            <div className="space-y-1">
              <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Primary Modules
              </div>

              {PRIMARY_COMMUNITY_NAV.map((mod) => {
                if (mod.requiredPermission && !hasPermission(authContext, mod.requiredPermission)) {
                  return null;
                }

                const isActive =
                  portalMode === 'COMMUNITY_DASHBOARD' &&
                  mod.matchingSections.includes(activeCommunitySection);
                const Icon = mod.icon;

                return (
                  <button
                    key={mod.id}
                    onClick={() => {
                      onSelectPortalMode('COMMUNITY_DASHBOARD');
                      onSelectCommunitySection(mod.id);
                      onClose();
                    }}
                    className={`group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-xs font-bold transition tracking-wide ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <Icon
                      className={`h-4 w-4 shrink-0 ${
                        isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'
                      }`}
                    />
                    <span className="truncate">{mod.label}</span>
                  </button>
                );
              })}

              <div className="pt-4 border-t border-slate-800 space-y-1">
                <div className="px-3 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Portal Switchers
                </div>

                {/* Recruiter Portal Link */}
                <button
                  onClick={() => {
                    onSelectPortalMode('RECRUITER_PORTAL');
                    onClose();
                  }}
                  className={`group flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium transition ${
                    portalMode === 'RECRUITER_PORTAL'
                      ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <User className="h-4 w-4 text-emerald-400" />
                  <span>My Recruiter Dashboard</span>
                </button>

                {/* Join Application Portal Link */}
                <button
                  onClick={() => {
                    onSelectPortalMode('APPLICANT_PORTAL');
                    onClose();
                  }}
                  className={`group flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium transition ${
                    portalMode === 'APPLICANT_PORTAL'
                      ? 'bg-amber-600 text-white shadow-xs font-semibold'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <FileText className="h-4 w-4 text-amber-400" />
                  <span>Join Application Form</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="border-t border-slate-800 p-4">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              Discord Gateway
            </span>
            <span className="font-mono text-slate-400">ONLINE</span>
          </div>
        </div>
      </aside>
    </>
  );
};
