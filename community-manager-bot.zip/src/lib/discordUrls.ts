/**
 * Authoritative Discord URL and Installation Configuration Helpers
 */

export interface AddToDiscordOptions {
  guildId?: string;
  redirectUri?: string;
}

/**
 * The Discord Client ID — sourced from VITE_DISCORD_CLIENT_ID at build time.
 * This is NOT a secret. It appears in every Discord OAuth URL.
 * It must match your server's DISCORD_CLIENT_ID exactly.
 */
export const AUTHORITATIVE_DISCORD_CLIENT_ID: string | undefined =
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_DISCORD_CLIENT_ID) || undefined;

export function isDiscordClientConfigured(): boolean {
  return Boolean(
    (typeof window !== 'undefined' && (window as any).__DISCORD_CLIENT_ID__) ||
    AUTHORITATIVE_DISCORD_CLIENT_ID
  );
}

export function getDiscordClientId(): string {
  return (
    (typeof window !== 'undefined' && (window as any).__DISCORD_CLIENT_ID__) ||
    AUTHORITATIVE_DISCORD_CLIENT_ID ||
    '1547515985416822884'
  );
}

function resolveClientIdOrWarn(): string {
  return getDiscordClientId();
}

/**
 * Returns the Add to Discord Bot installation URL.
 * Uses authoritative Client ID 1547515985416822884 and permission bitfield 2415982592.
 */
export function getAddToDiscordUrl(options: AddToDiscordOptions = {}): string {
  const clientId = resolveClientIdOrWarn();
  const permissions = '2415982592';
  const scopes = encodeURIComponent('bot applications.commands');
  let url = `https://discord.com/oauth2/authorize?client_id=${clientId}&scope=${scopes}&permissions=${permissions}`;

  if (options.guildId) {
    url += `&guild_id=${options.guildId}&disable_guild_select=true`;
  }

  if (options.redirectUri && !options.redirectUri.includes('discord.com') && options.redirectUri.startsWith('http')) {
    url += `&redirect_uri=${encodeURIComponent(options.redirectUri)}&response_type=code`;
  }

  return url;
}

/**
 * Returns the canonical Backend Discord OAuth Login entry point URL.
 * The server generates a secure cryptographically random state and redirects to Discord.
 */
export function getDiscordLoginUrl(): string {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  return `${origin}/api/v1/auth/login?redirect=true`;
}
